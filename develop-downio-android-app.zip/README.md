# Down.io

Her bağlantıdaki medyayı tarayan, önizleten ve seçtiklerinizi indiren Android uygulaması.
Tasarım dili: Apple HIG ilkeleri (sade, içerik önde, tek vurgu rengi, katmanlı derinlik, 44 px dokunma hedefi).

İki parça vardır:

| Parça | Klasör | Görevi |
| --- | --- | --- |
| **Tarama sunucusu** (Next.js + PostgreSQL) | `src/` | Bağlantıyı tarar, medya akışını proxy'ler, geçmişi saklar, arayüzü sunar |
| **Android uygulaması** (Kotlin WebView) | `android/` | APK. Arayüzü sunucudan yükler; indirme, haptic, pano ve oturum açma için yerel köprü sağlar |

> Tarama bir sunucuda yapılır, çünkü tarayıcı/WebView CORS nedeniyle başka sitelerin sayfalarını okuyamaz.
> Aynı nedenle trafik sunucudan geçer; "Engel aşma" özelliği de buna dayanır.

## 1) Sunucuyu çalıştırın

Gereksinimler: Node.js 20+, PostgreSQL, Python 3 (yt-dlp için).

```bash
npm install
# .env içinde DATABASE_URL tanımlı olmalı
npx drizzle-kit push      # tabloları oluşturur
npm run build && npm run start
```

- Sunucuyu HTTPS ile internete açın (VPS, Railway, Fly.io, kendi sunucunuz vb.).
- `yt-dlp` otomatik bulunur/indirilir (`YTDLP_PATH` ile elle de verilebilir). YouTube, TikTok, Instagram, Facebook,
  X canlı yayınları ve yüzlerce site için kullanılır. Bulut IP'lerinde YouTube "bot doğrulaması" isteyebilir;
  Ayarlar → Oturum bölümünden giriş yaparak aşılır.
- Uygulama herkese açık bir proxy gibi davranır; yalnızca kendiniz kullanacaksanız sunucuyu bir ters proxy
  (Basic Auth, VPN, Tailscale vb.) arkasında tutun.

## 2) APK üretin

1. `android/gradle.properties` içindeki `APP_URL=` satırına sunucu adresinizi yazın
   (boş bırakırsanız uygulama ilk açılışta adresi sorar).
2. **Android Studio**: `android/` klasörünü açın → *Build → Build Bundle(s) / APK(s) → Build APK(s)*.
   **Komut satırı** (JDK 17 + Android SDK gerekir):

   ```bash
   cd android
   ./gradlew assembleRelease     # çıktı: app/build/outputs/apk/release/app-release.apk
   ```
3. APK'yı telefona gönderip kurun (bilinmeyen kaynaklara izin verin).

İndirilen dosyalar `İndirilenler/Down.io/…` altına kaydedilir (klasör adı Ayarlar'dan değişir).
Başka uygulamalardan **Paylaş → Down.io** ile bağlantı gönderebilirsiniz.

## Özellikler

- **Açılış**: logolu yükleme animasyonu
- **İndir**: bağlantı yapıştır → tüm medya listelenir (tür, boyut, çözünürlük/süre), türe göre filtre, boyut/ad/tür sıralama,
  elle seçim, video kalite seçimi, **önizleme** (fotoğraf tam çözünürlük; video/ses indirmeden akıtılır), **toplu tarama**
- **Geçmiş**: indirmeler (kaynak bağlantı görünür + kopyalanır, dosyayı aç, tek tek/toplu sil) ve taranan bağlantılar (kopyala, yeniden tara, sil)
- **Ayarlar**: tema, haptic, öğretici, kayıt klasörü, türe göre klasör, varsayılan kalite, otomatik pano, eşzamanlı indirme,
  engel aşma (DoH + sunucu tüneli), önbellek temizliği, platform oturumları (uygulama içi giriş → çerez/SessionID otomatik aktarılır)
- **Hakkında**

## Platform notları

| Platform | Yöntem |
| --- | --- |
| GoFile | Resmî web API; dinamik website-token'ı GoFile'ın kendi betiğinden üretir; alt klasörler, sayfalama; şifreli klasör bildirilir ve şifreyle taranır |
| Yandex Disk | Genel API; klasörler özyinelemeli; **ZIP arşivleri indirilmeden içeriği okunur** (HTTP Range) ve içindeki dosyalar tek tek indirilir; indirme kapalıysa önizleme sunulur |
| X | Tweet: syndication; profil `/media`: GraphQL (oturum önerilir) + yedek; canlı yayın: yt-dlp |
| YouTube / TikTok / Facebook / Instagram | yt-dlp + yerel yedek çıkarıcılar; hikâye ve profil için oturum gerekir |
| Spotify | DRM nedeniyle yalnızca resmî 30 sn önizleme ve kapak |
| Diğer siteler | yt-dlp (yetişkin siteler dâhil) + genel HTML tarayıcı (img/video/source/og/JSON-LD/bağlantılar, HLS) |

Yalnızca indirme hakkınız olan içerikler için kullanın.
