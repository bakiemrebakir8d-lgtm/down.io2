"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { copyText, native } from "@/lib/client/native";
import { useSettings } from "@/lib/client/settings";
import { KIND_LABEL, formatBytes, type Kind } from "@/lib/types";
import { ICopy, IOpen, IRefresh, ITrash, KindIcon } from "./Icons";
import { useToast } from "./Toast";

interface Dl {
  id: number;
  title: string;
  filename: string;
  kind: Kind;
  size: number | null;
  sourceUrl: string;
  mediaUrl: string | null;
  localId: string | null;
  quality: string | null;
  createdAt: string;
}
interface Ln {
  id: number;
  url: string;
  platform: string | null;
  title: string | null;
  itemCount: number;
  scanCount: number;
  lastScannedAt: string;
}

const fmtDate = (d: string) =>
  new Date(d).toLocaleString("tr-TR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

export function HistoryView() {
  const { tap } = useSettings();
  const [tab, setTab] = useState<"dl" | "ln">("dl");
  const [dls, setDls] = useState<Dl[] | null>(null);
  const [lns, setLns] = useState<Ln[] | null>(null);
  const [confirmAll, setConfirmAll] = useState(false);
  const { show, node } = useToast();

  const load = useCallback(async () => {
    const [a, b] = await Promise.all([fetch("/api/history").then((r) => r.json()), fetch("/api/links").then((r) => r.json())]);
    setDls(a);
    setLns(b);
  }, []);
  useEffect(() => {
    load().catch(() => {
      setDls([]);
      setLns([]);
    });
  }, [load]);

  const copy = async (t: string) => {
    tap("light");
    show((await copyText(t)) ? "Bağlantı kopyalandı" : "Kopyalanamadı");
  };
  const del = async (kind: "history" | "links", id?: number) => {
    tap("light");
    await fetch(`/api/${kind}?${id ? `id=${id}` : "all=1"}`, { method: "DELETE" });
    setConfirmAll(false);
    show(id ? "Kayıt silindi" : "Tümü silindi");
    load();
  };
  const open = (d: Dl) => {
    tap("light");
    if (native.available() && d.localId) {
      if (!native.open(d.localId)) show("Dosya bulunamadı; silinmiş olabilir");
    } else if (d.mediaUrl) window.open(d.mediaUrl, "_blank");
  };

  const list = tab === "dl" ? dls : lns;
  return (
    <main className="page">
      <header className="hero">
        <h1 className="h1">Geçmiş</h1>
        <p className="sub">İndirmeleriniz ve taradığınız bağlantılar.</p>
      </header>

      <div className="seg" role="group" aria-label="Geçmiş türü">
        <button aria-pressed={tab === "dl"} onClick={() => { setTab("dl"); setConfirmAll(false); }}>İndirmeler</button>
        <button aria-pressed={tab === "ln"} onClick={() => { setTab("ln"); setConfirmAll(false); }}>Bağlantılar</button>
      </div>

      {list && list.length > 0 && (
        <div className="row" style={{ margin: "14px 0 6px", justifyContent: "space-between" }}>
          <span className="caption">{list.length} kayıt</span>
          {confirmAll ? (
            <span className="row" style={{ gap: 4 }}>
              <button className="btn plain" onClick={() => setConfirmAll(false)}>Vazgeç</button>
              <button className="btn danger" onClick={() => del(tab === "dl" ? "history" : "links")}>Evet, tümünü sil</button>
            </span>
          ) : (
            <button className="btn danger" onClick={() => setConfirmAll(true)}><ITrash size={18} /> Tümünü sil</button>
          )}
        </div>
      )}

      {list === null && <div className="card pad" style={{ marginTop: 16 }}><div className="progress indet"><i /></div></div>}
      {list && list.length === 0 && (
        <div style={{ textAlign: "center", padding: "64px 16px" }}>
          <h2 className="h2" style={{ margin: 0 }}>{tab === "dl" ? "Henüz indirme yok" : "Henüz bağlantı yok"}</h2>
          <p className="sub">{tab === "dl" ? "İndirdiğiniz her şey burada görünür." : "Taradığınız bağlantılar burada saklanır."}</p>
        </div>
      )}

      <div className="stack" style={{ marginTop: 10 }}>
        {tab === "dl" &&
          dls?.map((d) => (
            <article key={d.id} className="card pad stack" style={{ gap: 10 }}>
              <div className="row" style={{ alignItems: "flex-start" }}>
                <div style={{ color: "var(--accent)", paddingTop: 2 }}><KindIcon kind={d.kind} /></div>
                <div className="grow">
                  <div className="t clamp" style={{ fontWeight: 600 }}>{d.filename}</div>
                  <div className="row mono" style={{ gap: 6, flexWrap: "wrap", marginTop: 4 }}>
                    <span className="tag">{KIND_LABEL[d.kind] || d.kind}</span>
                    {d.quality && <span className="tag gray">{d.quality}</span>}
                    <span className="caption">{formatBytes(d.size)} · {fmtDate(d.createdAt)}</span>
                  </div>
                </div>
              </div>
              <div>
                <div className="caption">Kaynak bağlantı</div>
                <div className="urltext">{d.sourceUrl}</div>
              </div>
              <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
                <button className="btn" onClick={() => open(d)}><IOpen size={18} /> Aç</button>
                <button className="btn soft" onClick={() => copy(d.sourceUrl)}><ICopy size={18} /> Kopyala</button>
                <Link className="btn soft" href={`/?u=${encodeURIComponent(d.sourceUrl)}`}><IRefresh size={18} /> Tara</Link>
                <button className="btn danger" aria-label="Kaydı sil" onClick={() => del("history", d.id)}><ITrash size={18} /></button>
              </div>
            </article>
          ))}

        {tab === "ln" &&
          lns?.map((l) => (
            <article key={l.id} className="card pad stack" style={{ gap: 10 }}>
              <div className="row mono" style={{ gap: 6, flexWrap: "wrap" }}>
                {l.platform && <span className="tag">{l.platform}</span>}
                <span className="caption">{l.itemCount} medya · {l.scanCount}× tarandı · {fmtDate(l.lastScannedAt)}</span>
              </div>
              {l.title && <div className="t clamp" style={{ fontWeight: 600 }}>{l.title}</div>}
              <div className="urltext">{l.url}</div>
              <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
                <Link className="btn" href={`/?u=${encodeURIComponent(l.url)}`}><IRefresh size={18} /> Tara</Link>
                <button className="btn soft" onClick={() => copy(l.url)}><ICopy size={18} /> Kopyala</button>
                <button className="btn danger" aria-label="Bağlantıyı sil" onClick={() => del("links", l.id)}><ITrash size={18} /></button>
              </div>
            </article>
          ))}
      </div>
      {node}
    </main>
  );
}
