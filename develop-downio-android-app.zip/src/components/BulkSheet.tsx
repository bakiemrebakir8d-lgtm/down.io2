"use client";

import { useState } from "react";
import { isUrl } from "@/lib/client/native";
import { IClose, IPaste } from "./Icons";
import { native } from "@/lib/client/native";

export function BulkSheet({
  onRun,
  onClose,
  progress,
}: {
  onRun: (urls: string[]) => void;
  onClose: () => void;
  progress: { done: number; total: number } | null;
}) {
  const [text, setText] = useState("");
  const urls = [...new Set(text.split(/[\s,]+/).map((x) => x.trim()).filter((x) => x && isUrl(x)))];
  const busy = !!progress;
  return (
    <div className="scrim" role="dialog" aria-modal="true" aria-label="Toplu tarama" onClick={(e) => e.target === e.currentTarget && !busy && onClose()}>
      <div className="sheet">
        <div className="grab" />
        <div className="row" style={{ marginBottom: 8 }}>
          <div className="grow">
            <h2 className="h1" style={{ fontSize: 28 }}>Toplu tarama</h2>
            <p className="sub" style={{ fontSize: 15 }}>Her satıra bir bağlantı yapıştırın.</p>
          </div>
          <button className="icon-btn" aria-label="Kapat" onClick={onClose} disabled={busy}>
            <IClose />
          </button>
        </div>
        <textarea className="field" placeholder={"https://gofile.io/d/…\nhttps://x.com/kullanici/media\nhttps://youtu.be/…"} value={text} onChange={(e) => setText(e.target.value)} disabled={busy} aria-label="Bağlantılar" />
        {progress && (
          <div style={{ marginTop: 14 }}>
            <div className="progress"><i style={{ width: `${(progress.done / Math.max(1, progress.total)) * 100}%` }} /></div>
            <p className="caption mono" style={{ marginTop: 6 }}>{progress.done} / {progress.total} bağlantı tarandı</p>
          </div>
        )}
        <div className="row" style={{ marginTop: 16 }}>
          <button
            className="btn soft"
            disabled={busy}
            onClick={async () => {
              const t = await native.clipboard();
              if (t) setText((p) => (p ? p + "\n" : "") + t);
            }}
          >
            <IPaste size={20} /> Yapıştır
          </button>
          <button className="btn grow" disabled={busy || !urls.length} onClick={() => onRun(urls)}>
            {busy ? "Taranıyor…" : `${urls.length} bağlantıyı tara`}
          </button>
        </div>
      </div>
    </div>
  );
}
