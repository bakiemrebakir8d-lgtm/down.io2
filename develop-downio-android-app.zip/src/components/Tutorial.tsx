"use client";

import { useState } from "react";
import { useSettings } from "@/lib/client/settings";
import { IDownload, IHistory, ISearch, ISettings } from "./Icons";

const STEPS = [
  { Icon: ISearch, title: "Bağlantıyı yapıştır", text: "Herhangi bir sayfanın veya paylaşımın bağlantısını yapıştırın. Down.io içindeki tüm medyayı bulur." },
  { Icon: IDownload, title: "Seç ve indir", text: "Fotoğraf, video, ses ve belgeleri türüne ve boyutuna göre süzün, dilediklerinizi seçin. Videoda kaliteyi siz belirleyin." },
  { Icon: IHistory, title: "Geçmişte hep yanınızda", text: "İndirdikleriniz ve taradığınız bağlantılar kaydedilir. Tek dokunuşla açın, kopyalayın ya da yeniden tarayın." },
  { Icon: ISettings, title: "Size göre ayarlayın", text: "Tema, kayıt klasörü, eşzamanlı indirme, engel aşma ve özel hesap girişi Ayarlar'da." },
];

export function Tutorial({ onClose }: { onClose: () => void }) {
  const { set, tap } = useSettings();
  const [i, setI] = useState(0);
  const step = STEPS[i];
  const last = i === STEPS.length - 1;
  const done = () => {
    set({ tutorialSeen: true });
    onClose();
  };
  return (
    <div className="scrim" role="dialog" aria-modal="true" aria-label="Öğretici">
      <div className="sheet" style={{ textAlign: "center" }}>
        <div className="grab" />
        <div style={{ display: "grid", placeItems: "center", width: 88, height: 88, margin: "20px auto 8px", borderRadius: 26, background: "var(--accent-soft)", color: "var(--accent)" }}>
          <step.Icon size={44} />
        </div>
        <h2 className="h1" style={{ fontSize: 28, marginTop: 16 }}>{step.title}</h2>
        <p className="sub" style={{ margin: "10px auto 24px", maxWidth: 440 }}>{step.text}</p>
        <div style={{ display: "flex", justifyContent: "center", gap: 8, marginBottom: 24 }} aria-hidden="true">
          {STEPS.map((_, k) => (
            <span key={k} style={{ width: k === i ? 22 : 8, height: 8, borderRadius: 4, background: k === i ? "var(--accent)" : "var(--surface-2)", transition: "all .25s" }} />
          ))}
        </div>
        <div className="row" style={{ justifyContent: "center" }}>
          <button className="btn plain" onClick={done}>Atla</button>
          <button
            className="btn"
            style={{ minWidth: 160 }}
            onClick={() => {
              tap("light");
              if (last) done();
              else setI(i + 1);
            }}
          >
            {last ? "Başla" : "Devam"}
          </button>
        </div>
      </div>
    </div>
  );
}
