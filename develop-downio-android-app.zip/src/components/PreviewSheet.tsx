"use client";

import { useEffect, useState } from "react";
import { KIND_LABEL, formatBytes, formatDuration, type MediaItem, type Variant } from "@/lib/types";
import { IClose, IDownload, KindIcon } from "./Icons";

export function PreviewSheet({
  item,
  variant,
  onVariant,
  onDownload,
  onClose,
}: {
  item: MediaItem;
  variant: Variant;
  onVariant: (id: string) => void;
  onDownload: () => void;
  onClose: () => void;
}) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [variant.id]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);

  const playable = item.kind === "image" || item.kind === "video" || item.kind === "audio";
  return (
    <div className="scrim" role="dialog" aria-modal="true" aria-label="Önizleme" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sheet">
        <div className="grab" />
        <div className="row" style={{ marginBottom: 12 }}>
          <div className="grow">
            <div className="t clamp" style={{ fontWeight: 600, fontSize: 19, letterSpacing: "-0.025em" }}>{item.title}</div>
            <div className="caption mono">
              {KIND_LABEL[item.kind]} · {variant.ext.toUpperCase()} · {formatBytes(variant.size ?? item.size)}
              {item.duration ? ` · ${formatDuration(item.duration)}` : ""}
              {variant.height ? ` · ${variant.height}p` : ""}
            </div>
          </div>
          <button className="icon-btn" aria-label="Kapat" onClick={onClose}>
            <IClose />
          </button>
        </div>

        <div className="viewer">
          {failed ? (
            <div style={{ padding: 32, textAlign: "center", color: "#aaa" }}>
              <p style={{ margin: 0 }}>Bu kaynak tarayıcıda önizlenemedi.</p>
              <p className="caption" style={{ color: "#aaa" }}>Yine de indirebilirsiniz.</p>
            </div>
          ) : item.kind === "image" ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={variant.previewUrl} alt={item.title} onError={() => setFailed(true)} />
          ) : item.kind === "video" ? (
            <video key={variant.id} src={variant.previewUrl} poster={item.thumb} controls autoPlay playsInline preload="metadata" onError={() => setFailed(true)} />
          ) : item.kind === "audio" ? (
            <div style={{ width: "100%", display: "grid", placeItems: "center", color: "#fff", padding: "24px 0" }}>
              <KindIcon kind="audio" size={56} />
              <audio key={variant.id} src={variant.previewUrl} controls autoPlay onError={() => setFailed(true)} />
            </div>
          ) : (
            <div style={{ padding: 40, textAlign: "center", color: "#bbb" }}>
              <KindIcon kind={item.kind} size={56} />
              <p style={{ margin: "12px 0 0" }}>{KIND_LABEL[item.kind]} dosyaları için önizleme yok</p>
            </div>
          )}
        </div>
        {playable && item.kind === "video" && (
          <p className="caption" style={{ margin: "10px 4px 0" }}>Video indirilmeden doğrudan akıtılarak oynatılıyor.</p>
        )}
        {item.note && <p className="caption" style={{ margin: "10px 4px 0" }}>{item.note}</p>}

        <div className="row" style={{ marginTop: 16, flexWrap: "wrap" }}>
          {item.variants.length > 1 && (
            <select className="select" aria-label="Kalite" value={variant.id} onChange={(e) => onVariant(e.target.value)}>
              {item.variants.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.label} · {v.ext.toUpperCase()} · {formatBytes(v.size)}
                </option>
              ))}
            </select>
          )}
          <button className="btn grow" onClick={onDownload}>
            <IDownload size={20} /> İndir
          </button>
        </div>
      </div>
    </div>
  );
}
