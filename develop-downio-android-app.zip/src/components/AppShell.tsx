"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { DownloadsProvider, useDownloads } from "@/lib/client/downloads";
import { SettingsProvider, useSettings } from "@/lib/client/settings";
import { IDownload, IHistory, IInfo, ISettings } from "./Icons";
import { Logo } from "./Logo";
import { Tutorial } from "./Tutorial";

function Splash() {
  const [phase, setPhase] = useState<"show" | "out" | "gone">("show");
  useEffect(() => {
    const seen = sessionStorage.getItem("downio.splash");
    const t1 = window.setTimeout(() => setPhase("out"), seen ? 150 : 1900);
    const t2 = window.setTimeout(() => {
      setPhase("gone");
      sessionStorage.setItem("downio.splash", "1");
    }, seen ? 500 : 2500);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);
  if (phase === "gone") return null;
  return (
    <div className={`splash${phase === "out" ? " out" : ""}`} role="status" aria-label="Down.io yükleniyor">
      <Logo size={132} spin />
      <h1>Down.io</h1>
      <div className="bar" aria-hidden="true">
        <i />
      </div>
    </div>
  );
}

const TABS = [
  { href: "/", label: "İndir", Icon: IDownload },
  { href: "/history", label: "Geçmiş", Icon: IHistory },
  { href: "/settings", label: "Ayarlar", Icon: ISettings },
  { href: "/about", label: "Hakkında", Icon: IInfo },
];

function TabBar() {
  const path = usePathname();
  const { tap } = useSettings();
  const { active } = useDownloads();
  return (
    <div className="tabbar">
      <nav aria-label="Ana menü">
        {TABS.map(({ href, label, Icon }) => (
          <Link key={href} href={href} className="tab" aria-current={path === href ? "page" : undefined} onClick={() => tap("light")}>
            <span style={{ position: "relative", display: "inline-flex" }}>
              <Icon size={26} />
              {href === "/" && active > 0 && (
                <span
                  style={{ position: "absolute", top: -4, right: -10, minWidth: 18, height: 18, borderRadius: 9, background: "var(--accent)", color: "var(--on-accent)", fontSize: 12, fontWeight: 700, display: "grid", placeItems: "center", padding: "0 5px" }}
                >
                  {active}
                </span>
              )}
            </span>
            {label}
          </Link>
        ))}
      </nav>
    </div>
  );
}

function Inner({ children }: { children: ReactNode }) {
  const { s, ready } = useSettings();
  const [showTut, setShowTut] = useState(false);
  useEffect(() => {
    if (ready && !s.tutorialSeen) {
      const t = window.setTimeout(() => setShowTut(true), 2600);
      return () => clearTimeout(t);
    }
  }, [ready, s.tutorialSeen]);
  useEffect(() => {
    const open = () => setShowTut(true);
    window.addEventListener("downio:tutorial", open);
    return () => window.removeEventListener("downio:tutorial", open);
  }, []);
  return (
    <>
      <Splash />
      {children}
      <TabBar />
      {showTut && <Tutorial onClose={() => setShowTut(false)} />}
    </>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <SettingsProvider>
      <DownloadsProvider>
        <Inner>{children}</Inner>
      </DownloadsProvider>
    </SettingsProvider>
  );
}
