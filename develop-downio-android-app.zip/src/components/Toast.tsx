"use client";

import { useCallback, useEffect, useState } from "react";

export function useToast() {
  const [msg, setMsg] = useState("");
  useEffect(() => {
    if (!msg) return;
    const t = window.setTimeout(() => setMsg(""), 2200);
    return () => clearTimeout(t);
  }, [msg]);
  const show = useCallback((m: string) => setMsg(m), []);
  const node = msg ? (
    <div
      role="status"
      style={{
        position: "fixed",
        left: "50%",
        transform: "translateX(-50%)",
        bottom: "calc(var(--tab-h) + env(safe-area-inset-bottom) + 24px)",
        zIndex: 80,
        background: "var(--text)",
        color: "var(--bg)",
        padding: "12px 20px",
        borderRadius: 999,
        fontSize: 15,
        fontWeight: 500,
        boxShadow: "var(--shadow-2)",
        maxWidth: "90vw",
        animation: "rise .25s ease both",
      }}
    >
      {msg}
    </div>
  ) : null;
  return { show, node };
}
