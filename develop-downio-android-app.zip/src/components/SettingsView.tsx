"use client";

import { Fragment, useEffect, useState, type ReactNode } from "react";
import { PLATFORMS, native } from "@/lib/client/native";
import { useSettings, type Settings } from "@/lib/client/settings";
import { IClose } from "./Icons";
import { useToast } from "./Toast";

function Group({ title, children }: { title: string; children: ReactNode[] }) {
  return (
    <section>
      <h2 className="caption" style={{ textTransform: "uppercase", letterSpacing: "0.04em", margin: "28px 16px 8px", fontWeight: 600 }}>{title}</h2>
      <div className="card">
        {children.filter(Boolean).map((c, i) => (
          <Fragment key={i}>
            {i > 0 && <div className="sep" />}
            {c}
          </Fragment>
        ))}
      </div>
    </section>
  );
}

function Row({ title, desc, children, stack }: { title: string; desc?: string; children?: ReactNode; stack?: boolean }) {
  return (
    <div className="list-row" style={stack ? { flexDirection: "column", alignItems: "stretch", gap: 10, padding: "14px 16px" } : { padding: "8px 16px" }}>
      <div className="grow">
        <div className="t">{title}</div>
        {desc && <div className="caption">{desc}</div>}
      </div>
      {children}
    </div>
  );
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="switch-wrap">
      <input type="checkbox" className="switch" role="switch" aria-label={label} checked={on} onChange={(e) => onChange(e.target.checked)} />
    </label>
  );
}

export function SettingsView() {
  const { s, set, setCookie, tap } = useSettings();
  const { show, node } = useToast();
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [server, setServer] = useState("");
  const [isNative, setIsNative] = useState(false);
  const [cacheInfo, setCacheInfo] = useState("");

  useEffect(() => {
    setIsNative(native.available());
    setServer(native.getServerUrl());
    navigator.storage?.estimate?.().then((e) => e.usage && setCacheInfo(`${(e.usage / 1048576).toFixed(1)} MB`)).catch(() => {});
  }, []);

  const upd = (p: Partial<Settings>) => {
    set(p);
    tap("light");
  };

  const clearCache = async () => {
    tap("light");
    await fetch("/api/cache", { method: "DELETE" }).catch(() => {});
    try {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    } catch {
      /* yoksay */
    }
    native.clearCache();
    setCacheInfo("0 MB");
    show("Önbellek temizlendi");
    tap("success");
  };

  const platform = PLATFORMS.find((p) => p.key === editing);

  return (
    <main className="page">
      <header className="hero">
        <h1 className="h1">Ayarlar</h1>
        <p className="sub">Down.io&apos;yu size göre düzenleyin.</p>
      </header>

      <Group title="Genel ve görünüm">
        {[
          <Row key="theme" title="Tema" stack>
            <div className="seg" role="group" aria-label="Tema">
              {(["auto", "light", "dark"] as const).map((t) => (
                <button key={t} aria-pressed={s.theme === t} onClick={() => upd({ theme: t })}>
                  {t === "auto" ? "Otomatik" : t === "light" ? "Açık" : "Koyu"}
                </button>
              ))}
            </div>
          </Row>,
          <Row key="haptic" title="Dokunsal geri bildirim" desc="Dokunuş ve işlem sonuçlarında hafif titreşim">
            <Toggle label="Dokunsal geri bildirim" on={s.haptic} onChange={(v) => { set({ haptic: v }); if (v) native.haptic("light"); }} />
          </Row>,
          <Row key="tut" title="Öğretici" desc="Uygulamanın nasıl kullanılacağını yeniden göster">
            <button className="btn soft" onClick={() => window.dispatchEvent(new Event("downio:tutorial"))}>Göster</button>
          </Row>,
        ]}
      </Group>

      <Group title="İndirme ve dosya">
        {[
          <Row key="folder" title="Kayıt klasörü" desc={`Konum: İndirilenler/${s.folder || "Down.io"}`} stack>
            <input className="field" style={{ minHeight: 44, boxShadow: "none", background: "var(--surface-2)" }} aria-label="Kayıt klasörü" value={s.folder} onChange={(e) => set({ folder: e.target.value.replace(/[\\:*?"<>|]/g, "") })} placeholder="Down.io" />
          </Row>,
          <Row key="bytype" title="Türe göre alt klasör" desc="Fotoğraflar, Videolar, Belgeler… olarak ayır">
            <Toggle label="Türe göre alt klasör" on={s.byType} onChange={(v) => upd({ byType: v })} />
          </Row>,
          <Row key="quality" title="Varsayılan indirme kalitesi" desc="Birden fazla seçenek sunan videolarda">
            <select className="select" aria-label="Varsayılan kalite" value={s.quality} onChange={(e) => upd({ quality: e.target.value as Settings["quality"] })}>
              <option value="best">En yüksek</option>
              <option value="1080">1080p</option>
              <option value="720">720p</option>
              <option value="480">480p</option>
              <option value="worst">En düşük</option>
            </select>
          </Row>,
          <Row key="clip" title="Otomatik pano" desc="Panoya kopyalanan bağlantıyı algıla ve öner">
            <Toggle label="Otomatik pano" on={s.autoClipboard} onChange={(v) => upd({ autoClipboard: v })} />
          </Row>,
          <Row key="conc" title="Eşzamanlı indirme" desc="Aynı anda indirilecek dosya sayısı">
            <div className="row" style={{ gap: 4 }}>
              <button className="icon-btn" aria-label="Azalt" onClick={() => upd({ concurrent: Math.max(1, s.concurrent - 1) })} style={{ fontSize: 24 }}>−</button>
              <span className="mono" style={{ minWidth: 24, textAlign: "center", fontWeight: 600 }}>{s.concurrent}</span>
              <button className="icon-btn" aria-label="Artır" onClick={() => upd({ concurrent: Math.min(6, s.concurrent + 1) })} style={{ fontSize: 24 }}>+</button>
            </div>
          </Row>,
        ]}
      </Group>

      <Group title="Ağ ve erişim">
        {[
          <Row key="bypass" title="Engel aşma" desc="Güvenli DNS (DoH) çözümlemesi kullanır; tüm trafik sunucu üzerinden geçtiği için VPN olmadan erişim kısıtlı sitelere ulaşılır.">
            <Toggle label="Engel aşma" on={s.bypass} onChange={(v) => upd({ bypass: v })} />
          </Row>,
          <Row key="cache" title="Görsel önbellek" desc={cacheInfo ? `Kullanılan: ${cacheInfo}` : "Küçük resimler ve tarama sonuçları"}>
            <button className="btn soft" onClick={clearCache}>Temizle</button>
          </Row>,
          isNative ? (
            <Row key="server" title="Sunucu adresi" desc="Down.io tarama sunucusunun adresi" stack>
              <div className="row">
                <input className="field grow" style={{ minHeight: 44, boxShadow: "none", background: "var(--surface-2)" }} aria-label="Sunucu adresi" value={server} onChange={(e) => setServer(e.target.value)} placeholder="https://sunucum.com" inputMode="url" autoCapitalize="none" />
                <button className="btn" onClick={() => { native.setServerUrl(server); show("Kaydedildi; uygulama yeniden yüklenecek"); }}>Kaydet</button>
              </div>
            </Row>
          ) : null,
        ]}
      </Group>

      <Group title="Oturum (isteğe bağlı)">
        {[
          <Row key="info" title="Özel veya gizli içerikler" desc="Giriş gerektiren platformlarda oturum çerezleri taramaya otomatik eklenir. Çerezler yalnızca bu cihazda saklanır." />,
          ...PLATFORMS.map((p) => {
            const has = !!s.cookies[p.key];
            return (
              <Row key={p.key} title={p.name} desc={has ? "Oturum bağlı" : "Bağlı değil"}>
                <div className="row" style={{ gap: 6 }}>
                  {isNative && p.login && (
                    <button className="btn" onClick={() => { tap("light"); native.openLogin(p.login, p.cookieUrl, p.key); }}>Giriş yap</button>
                  )}
                  <button className="btn soft" onClick={() => { setEditing(p.key); setDraft(s.cookies[p.key] || ""); }}>{has ? "Düzenle" : "Çerez ekle"}</button>
                </div>
              </Row>
            );
          }),
        ]}
      </Group>

      {platform && (
        <div className="scrim" role="dialog" aria-modal="true" aria-label={`${platform.name} oturumu`} onClick={(e) => e.target === e.currentTarget && setEditing(null)}>
          <div className="sheet">
            <div className="grab" />
            <div className="row" style={{ marginBottom: 8 }}>
              <div className="grow">
                <h2 className="h1" style={{ fontSize: 26 }}>{platform.name} oturumu</h2>
                <p className="sub" style={{ fontSize: 15 }}>Cookie başlığını veya <code>sessionid=…; csrftoken=…</code> satırını yapıştırın.</p>
              </div>
              <button className="icon-btn" aria-label="Kapat" onClick={() => setEditing(null)}><IClose /></button>
            </div>
            <textarea className="field" style={{ minHeight: 140 }} value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="sessionid=…; csrftoken=…" aria-label="Çerez" autoCapitalize="none" spellCheck={false} />
            <div className="row" style={{ marginTop: 16 }}>
              {s.cookies[platform.key] && (
                <button className="btn danger" onClick={() => { setCookie(platform.key, ""); setEditing(null); show("Oturum kaldırıldı"); }}>Kaldır</button>
              )}
              <button className="btn grow" onClick={() => { setCookie(platform.key, draft); setEditing(null); tap("success"); show("Oturum kaydedildi"); }}>Kaydet</button>
            </div>
          </div>
        </div>
      )}
      {node}
    </main>
  );
}
