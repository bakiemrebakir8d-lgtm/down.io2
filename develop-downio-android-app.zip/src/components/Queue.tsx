"use client";

import { useDownloads } from "@/lib/client/downloads";
import { formatBytes } from "@/lib/types";
import { ICheck, IClose } from "./Icons";

export function Queue() {
  const { jobs, cancel, clearFinished } = useDownloads();
  if (!jobs.length) return null;
  const finished = jobs.some((j) => j.status === "done" || j.status === "error" || j.status === "canceled");
  return (
    <section aria-label="İndirme kuyruğu">
      <div className="row" style={{ margin: "28px 0 12px" }}>
        <h2 className="h2 grow" style={{ margin: 0 }}>İndirmeler</h2>
        {finished && (
          <button className="btn plain" onClick={clearFinished}>
            Temizle
          </button>
        )}
      </div>
      <div className="card">
        {[...jobs].reverse().map((j, i) => {
          const pct = j.total > 0 ? Math.min(100, Math.round((j.loaded / j.total) * 100)) : 0;
          return (
            <div key={j.id}>
              {i > 0 && <div className="sep" />}
              <div className="list-row" style={{ alignItems: "flex-start", paddingTop: 14, paddingBottom: 14 }}>
                <div className="grow">
                  <div className="t clamp">{j.filename}</div>
                  <div className="caption mono" style={{ margin: "2px 0 8px" }}>
                    {j.status === "queued" && "Sırada"}
                    {j.status === "running" && (j.total > 0 ? `%${pct} · ${formatBytes(j.loaded)} / ${formatBytes(j.total)}` : j.loaded > 0 ? formatBytes(j.loaded) : "İndiriliyor…")}
                    {j.status === "done" && (
                      <span style={{ color: "var(--success)", display: "inline-flex", alignItems: "center", gap: 4 }}>
                        <ICheck size={14} /> Tamamlandı · {formatBytes(j.total || j.size)}
                      </span>
                    )}
                    {j.status === "error" && <span style={{ color: "var(--danger)" }}>{j.error || "Hata"}</span>}
                    {j.status === "canceled" && "İptal edildi"}
                  </div>
                  {(j.status === "running" || j.status === "queued") && (
                    <div className={`progress${j.status === "running" && j.total <= 0 ? " indet" : ""}`}>
                      <i style={{ width: `${pct}%` }} />
                    </div>
                  )}
                </div>
                {(j.status === "running" || j.status === "queued") && (
                  <button className="icon-btn" aria-label="İptal et" onClick={() => cancel(j.id)}>
                    <IClose />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
