"use client";

import { useSearchParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useDownloads } from "@/lib/client/downloads";
import { isUrl, native } from "@/lib/client/native";
import { useSettings } from "@/lib/client/settings";
import {
  KIND_LABEL,
  formatBytes,
  formatDuration,
  pickVariant,
  type Kind,
  type MediaItem,
  type ScanResult,
} from "@/lib/types";
import { BulkSheet } from "./BulkSheet";
import { ICheck, IDownload, IList, ILock, IPaste, IPlay, ISearch, KindIcon } from "./Icons";
import { PreviewSheet } from "./PreviewSheet";
import { Queue } from "./Queue";

type Filter = "all" | Kind;
type Sort = "default" | "size-desc" | "size-asc" | "name" | "type";
const KINDS: Kind[] = ["image", "video", "audio", "document", "archive", "other"];

export function DownloadView() {
  const { s, ready, tap } = useSettings();
  const { enqueue } = useDownloads();
  const params = useSearchParams();

  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [res, setRes] = useState<ScanResult | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [sort, setSort] = useState<Sort>("default");
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [vsel, setVsel] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<MediaItem | null>(null);
  const [bulk, setBulk] = useState(false);
  const [bulkProg, setBulkProg] = useState<{ done: number; total: number } | null>(null);
  const [pw, setPw] = useState("");
  const [clip, setClip] = useState("");
  const sources = useRef<Record<string, string>>({});
  const lastClip = useRef("");

  const options = useCallback(
    (password?: string) => ({ bypass: s.bypass, password, cookies: s.cookies }),
    [s.bypass, s.cookies],
  );

  const scanOne = useCallback(
    async (u: string, password?: string): Promise<ScanResult> => {
      const r = await fetch("/api/scan", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ url: u, options: options(password) }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Tarama başarısız");
      return j as ScanResult;
    },
    [options],
  );

  const scan = useCallback(
    async (u: string, password?: string) => {
      const target = u.trim();
      if (!target) return;
      setLoading(true);
      setErr("");
      setRes(null);
      setSel(new Set());
      setFilter("all");
      setClip("");
      try {
        const r = await scanOne(target, password);
        r.items.forEach((i) => (sources.current[i.id] = r.url));
        setRes(r);
        tap(r.items.length ? "success" : "error");
      } catch (e) {
        setErr((e as Error).message);
        tap("error");
      } finally {
        setLoading(false);
      }
    },
    [scanOne, tap],
  );

  // ?u= ile gelen (geçmişten yeniden tara)
  const autoDone = useRef(false);
  useEffect(() => {
    const u = params.get("u");
    if (u && ready && !autoDone.current) {
      autoDone.current = true;
      setUrl(u);
      scan(u);
    }
  }, [params, ready, scan]);

  // Otomatik pano
  useEffect(() => {
    if (!ready || !s.autoClipboard) return;
    const check = async () => {
      if (document.visibilityState !== "visible") return;
      const t = (await native.clipboard()).trim();
      if (t && t !== lastClip.current && isUrl(t)) {
        lastClip.current = t;
        setClip(t);
      }
    };
    check();
    document.addEventListener("visibilitychange", check);
    window.addEventListener("focus", check);
    return () => {
      document.removeEventListener("visibilitychange", check);
      window.removeEventListener("focus", check);
    };
  }, [ready, s.autoClipboard]);

  const runBulk = async (urls: string[]) => {
    setBulkProg({ done: 0, total: urls.length });
    const items: MediaItem[] = [];
    const warnings: string[] = [];
    let idx = 0;
    let done = 0;
    const worker = async () => {
      while (idx < urls.length) {
        const u = urls[idx++];
        try {
          const r = await scanOne(u);
          for (const it of r.items) {
            sources.current[it.id] = r.url;
            items.push({ ...it, folder: [r.platform, it.folder].filter(Boolean).join("/") });
          }
          r.warnings.forEach((w) => warnings.push(`${u}: ${w}`));
        } catch (e) {
          warnings.push(`${u}: ${(e as Error).message}`);
        }
        setBulkProg({ done: ++done, total: urls.length });
      }
    };
    await Promise.all([worker(), worker()]);
    setBulkProg(null);
    setBulk(false);
    setSel(new Set());
    setErr("");
    setFilter("all");
    setRes({ url: urls[0], platform: "Toplu", title: `${urls.length} bağlantı`, items, warnings, locked: undefined });
    tap("success");
  };

  const variantOf = useCallback(
    (it: MediaItem) => it.variants.find((v) => v.id === vsel[it.id]) || pickVariant(it, s.quality),
    [vsel, s.quality],
  );

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: res?.items.length || 0 };
    res?.items.forEach((i) => (c[i.kind] = (c[i.kind] || 0) + 1));
    return c;
  }, [res]);

  const visible = useMemo(() => {
    let list = (res?.items || []).filter((i) => filter === "all" || i.kind === filter);
    const size = (i: MediaItem) => variantOf(i).size ?? i.size ?? -1;
    if (sort === "size-desc") list = [...list].sort((a, b) => size(b) - size(a));
    if (sort === "size-asc") list = [...list].sort((a, b) => (size(a) < 0 ? 1e18 : size(a)) - (size(b) < 0 ? 1e18 : size(b)));
    if (sort === "name") list = [...list].sort((a, b) => a.title.localeCompare(b.title, "tr", { numeric: true }));
    if (sort === "type") list = [...list].sort((a, b) => KINDS.indexOf(a.kind) - KINDS.indexOf(b.kind) || a.title.localeCompare(b.title, "tr", { numeric: true }));
    return list;
  }, [res, filter, sort, variantOf]);

  const toggle = (id: string) => {
    tap("light");
    setSel((p) => {
      const n = new Set(p);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  };
  const allSelected = visible.length > 0 && visible.every((i) => sel.has(i.id));
  const toggleAll = () => {
    tap("light");
    setSel((p) => {
      const n = new Set(p);
      if (allSelected) visible.forEach((i) => n.delete(i.id));
      else visible.forEach((i) => n.add(i.id));
      return n;
    });
  };

  const download = (items: MediaItem[]) => {
    enqueue(
      items.map((it) => {
        const v = variantOf(it);
        return {
          title: it.title,
          filename: v.filename,
          kind: it.kind,
          size: v.size ?? it.size,
          url: v.downloadUrl,
          sourceUrl: sources.current[it.id] || res?.url || "",
          mediaUrl: v.previewUrl,
          quality: it.variants.length > 1 ? v.label : undefined,
        };
      }),
    );
    tap("success");
  };

  const selected = (res?.items || []).filter((i) => sel.has(i.id));
  const selSize = selected.reduce((a, i) => a + (variantOf(i).size ?? i.size ?? 0), 0);
  const unknown = selected.some((i) => (variantOf(i).size ?? i.size) === undefined);

  const paste = async () => {
    const t = (await native.clipboard()).trim();
    if (t) {
      setUrl(t);
      tap("light");
    }
  };

  return (
    <main className="page">
      <header className="hero">
        <h1 className="h1">İndir</h1>
        <p className="sub">Bağlantıyı yapıştır, medyayı bul.</p>
      </header>

      <form
        className="stack"
        onSubmit={(e) => {
          e.preventDefault();
          scan(url);
        }}
      >
        <div className="row">
          <input
            className="field grow"
            inputMode="url"
            autoCapitalize="none"
            autoCorrect="off"
            spellCheck={false}
            placeholder="https://"
            aria-label="Bağlantı"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
          <button type="button" className="btn soft" aria-label="Panodan yapıştır" onClick={paste} style={{ width: 52, height: 52, padding: 0 }}>
            <IPaste />
          </button>
        </div>
        <div className="row">
          <button className="btn grow" type="submit" disabled={loading || !url.trim()}>
            {loading ? <span className="spinner" /> : <ISearch size={20} />} {loading ? "Taranıyor…" : "Tara"}
          </button>
          <button type="button" className="btn soft" onClick={() => setBulk(true)}>
            <IList size={20} /> Toplu
          </button>
        </div>
      </form>

      {clip && !loading && clip !== url && (
        <div className="banner" style={{ marginTop: 14 }}>
          <div className="grow">
            <div style={{ fontWeight: 600 }}>Panoda bir bağlantı var</div>
            <div className="caption" style={{ wordBreak: "break-all" }}>{clip}</div>
          </div>
          <button
            className="btn"
            onClick={() => {
              setUrl(clip);
              scan(clip);
            }}
          >
            Tara
          </button>
          <button className="btn plain" onClick={() => setClip("")}>Gizle</button>
        </div>
      )}

      {err && (
        <div className="banner err" style={{ marginTop: 14 }} role="alert">
          <div className="grow">{err}</div>
        </div>
      )}

      {loading && (
        <div className="card pad" style={{ marginTop: 20 }}>
          <div className="progress indet"><i /></div>
          <p className="caption" style={{ margin: "10px 0 0" }}>Sayfa ve içerdiği medyalar taranıyor. Büyük klasörler biraz sürebilir.</p>
        </div>
      )}

      {res?.locked === "password" && (
        <form
          className="card pad stack"
          style={{ marginTop: 20 }}
          onSubmit={(e) => {
            e.preventDefault();
            scan(url || res.url, pw);
          }}
        >
          <div className="row"><ILock /> <strong>Bu klasör şifre korumalı</strong></div>
          <input className="field" type="password" placeholder="Klasör şifresi" aria-label="Klasör şifresi" value={pw} onChange={(e) => setPw(e.target.value)} />
          <button className="btn" disabled={!pw}>Şifreyle tara</button>
        </form>
      )}

      {res && (
        <section aria-label="Tarama sonuçları">
          <div className="row" style={{ margin: "28px 0 4px" }}>
            <div className="grow">
              <h2 className="h2" style={{ margin: 0 }} >{res.items.length} medya bulundu</h2>
              <div className="caption clamp">{res.platform} · {res.title}</div>
            </div>
          </div>

          {res.warnings.length > 0 && (
            <div className="banner warn" style={{ margin: "10px 0" }}>
              <ul style={{ margin: 0, paddingLeft: 18, fontSize: 15 }}>
                {res.warnings.slice(0, 6).map((w) => <li key={w}>{w}</li>)}
                {res.warnings.length > 6 && <li>… ve {res.warnings.length - 6} uyarı daha</li>}
              </ul>
            </div>
          )}

          {res.items.length > 0 && (
            <>
              <div className="chips" role="group" aria-label="Türe göre süz">
                {(["all", ...KINDS] as Filter[])
                  .filter((k) => k === "all" || counts[k])
                  .map((k) => (
                    <button key={k} className="chip" aria-pressed={filter === k} onClick={() => { tap("light"); setFilter(k); }}>
                      {k === "all" ? "Tümü" : KIND_LABEL[k]} <small>{counts[k] || 0}</small>
                    </button>
                  ))}
              </div>
              <div className="row" style={{ margin: "6px 0 14px", flexWrap: "wrap" }}>
                <select className="select" aria-label="Sırala" value={sort} onChange={(e) => setSort(e.target.value as Sort)}>
                  <option value="default">Sıralama: Varsayılan</option>
                  <option value="size-desc">Boyut: Büyükten küçüğe</option>
                  <option value="size-asc">Boyut: Küçükten büyüğe</option>
                  <option value="name">Ad: A–Z</option>
                  <option value="type">Tür</option>
                </select>
                <button className="btn plain" onClick={toggleAll}>{allSelected ? "Seçimi kaldır" : "Tümünü seç"}</button>
              </div>

              <div className="stack">
                {visible.map((it) => {
                  const v = variantOf(it);
                  const on = sel.has(it.id);
                  const thumb = it.thumb || (it.kind === "image" ? it.variants[0].previewUrl : undefined);
                  return (
                    <article key={it.id} className="card">
                      <div className="media">
                        <button className="check" role="checkbox" aria-checked={on} aria-label={`${it.title} seç`} onClick={() => toggle(it.id)}>
                          <span><ICheck size={16} /></span>
                        </button>
                        <button className="thumb" aria-label={`${it.title} önizle`} onClick={() => { tap("light"); setPreview(it); }}>
                          {thumb ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={thumb} alt="" loading="lazy" decoding="async" />
                          ) : (
                            <KindIcon kind={it.kind} />
                          )}
                          {(it.kind === "video" || it.kind === "audio") && <span className="play"><IPlay size={12} /></span>}
                        </button>
                        <div className="grow">
                          <div className="t clamp" style={{ fontWeight: 600 }}>{it.title}</div>
                          <div className="row mono" style={{ gap: 6, flexWrap: "wrap", margin: "4px 0 0" }}>
                            <span className="tag">{KIND_LABEL[it.kind]}</span>
                            <span className="tag gray">{v.ext}</span>
                            <span className="caption">{formatBytes(v.size ?? it.size)}</span>
                            {it.duration ? <span className="caption">{formatDuration(it.duration)}</span> : null}
                          </div>
                          {it.folder && <div className="caption clamp" style={{ marginTop: 2 }}>{it.folder}</div>}
                          {it.note && <div className="caption" style={{ marginTop: 2 }}>{it.note}</div>}
                        </div>
                      </div>
                      {it.variants.length > 1 && (
                        <div className="row" style={{ padding: "0 12px 12px 68px" }}>
                          <select className="select" aria-label="Kalite" value={v.id} onChange={(e) => setVsel((p) => ({ ...p, [it.id]: e.target.value }))}>
                            {it.variants.map((x) => (
                              <option key={x.id} value={x.id}>{x.label} · {x.ext.toUpperCase()} · {formatBytes(x.size)}</option>
                            ))}
                          </select>
                        </div>
                      )}
                    </article>
                  );
                })}
                {!visible.length && <p className="caption" style={{ textAlign: "center", padding: 24 }}>Bu türde medya yok.</p>}
              </div>
            </>
          )}
        </section>
      )}

      <Queue />

      {selected.length > 0 && (
        <div className="actionbar" role="region" aria-label="Seçim işlemleri">
          <div className="grow">
            <div style={{ fontWeight: 600 }}>{selected.length} seçili</div>
            <div className="caption mono">{formatBytes(selSize)}{unknown ? "+" : ""}</div>
          </div>
          <button className="btn plain" onClick={() => setSel(new Set())}>Bırak</button>
          <button className="btn" onClick={() => { download(selected); setSel(new Set()); }}>
            <IDownload size={20} /> İndir
          </button>
        </div>
      )}

      {preview && (
        <PreviewSheet
          item={preview}
          variant={variantOf(preview)}
          onVariant={(id) => setVsel((p) => ({ ...p, [preview.id]: id }))}
          onDownload={() => { download([preview]); setPreview(null); }}
          onClose={() => setPreview(null)}
        />
      )}
      {bulk && <BulkSheet onRun={runBulk} onClose={() => setBulk(false)} progress={bulkProg} />}
    </main>
  );
}
