export function Logo({ size = 96, spin = false }: { size?: number; spin?: boolean }) {
  return (
    <svg className="logo" width={size} height={size} viewBox="0 0 100 100" role="img" aria-label="Down.io logosu">
      <defs>
        <linearGradient id="lg-bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#eaf1ff" />
        </linearGradient>
        <linearGradient id="lg-b" x1="0.2" y1="0" x2="0.8" y2="1">
          <stop offset="0" stopColor="#3dbaff" />
          <stop offset="1" stopColor="#0036e8" />
        </linearGradient>
        <linearGradient id="lg-r" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8fd0ff" />
          <stop offset="0.5" stopColor="#2a7bff" />
          <stop offset="1" stopColor="#0a55f5" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="96" height="96" rx="24" fill="url(#lg-bg)" />
      <path d="M2 36C2 20 14 8 30 4 45 5 33 22 2 36Z" fill="#cfe0ff" opacity="0.7" />
      <path d="M98 70c0 16-12 28-28 28H38c26-6 38-18 60-28Z" fill="#cfe0ff" opacity="0.7" />
      <g className={spin ? "ring" : undefined}>
        <path d="M28.1 76A34 34 0 1 1 71.9 76" fill="none" stroke="url(#lg-r)" strokeWidth="6.2" strokeLinecap="butt" />
      </g>
      <path d="M40 28H60V46H70L50 68 30 46H40Z" fill="url(#lg-b)" stroke="url(#lg-b)" strokeWidth="3.4" strokeLinejoin="round" />
      <path d="M29.5 64V68a7 7 0 0 0 7 7H63.5a7 7 0 0 0 7-7V64" fill="none" stroke="url(#lg-b)" strokeWidth="7" strokeLinecap="round" />
    </svg>
  );
}
