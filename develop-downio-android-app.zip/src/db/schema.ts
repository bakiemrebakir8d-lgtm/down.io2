import {
  bigint,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const downloads = pgTable("downloads", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  filename: text("filename").notNull(),
  kind: text("kind").notNull().default("other"),
  size: bigint("size", { mode: "number" }),
  sourceUrl: text("source_url").notNull(),
  mediaUrl: text("media_url"),
  localId: text("local_id"),
  quality: text("quality"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const scannedLinks = pgTable("scanned_links", {
  id: serial("id").primaryKey(),
  url: text("url").notNull().unique(),
  platform: text("platform"),
  title: text("title"),
  itemCount: integer("item_count").notNull().default(0),
  scanCount: integer("scan_count").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastScannedAt: timestamp("last_scanned_at").defaultNow().notNull(),
});
