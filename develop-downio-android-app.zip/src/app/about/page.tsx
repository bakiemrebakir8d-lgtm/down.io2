import { Logo } from "@/components/Logo";

const PLATFORMS = [
  "YouTube — video, müzik, Shorts",
  "Spotify — 30 sn resmî önizleme",
  "Instagram — Reels, Hikâye, Gönderi",
  "Facebook — Reels ve video",
  "X — video, canlı yayın, fotoğraf, /media galerisi",
  "TikTok",
  "GoFile — klasörler, alt klasörler, şifre bildirimi",
  "Yandex Disk — arşiv içi dahil",
  "Diğer tüm web siteleri ve doğrudan dosya bağlantıları",
];

export default function Page() {
  return (
    <main className="page">
      <header className="hero" style={{ textAlign: "center", paddingTop: 32 }}>
        <div style={{ display: "grid", placeItems: "center", filter: "drop-shadow(0 16px 36px rgba(0,102,255,.25))" }}>
          <Logo size={112} />
        </div>
        <h1 className="h1" style={{ marginTop: 20 }}>Down.io</h1>
        <p className="sub">Sürüm 1.0.0</p>
      </header>

      <p style={{ textAlign: "center", margin: "0 auto 8px", maxWidth: 520 }}>
        Her bağlantıdaki medyayı bulur, önizletir ve seçtiklerinizi indirir.
      </p>

      <h2 className="h2">Desteklenenler</h2>
      <div className="card">
        {PLATFORMS.map((p, i) => (
          <div key={p}>
            {i > 0 && <div className="sep" />}
            <div className="list-row">{p}</div>
          </div>
        ))}
      </div>

      <h2 className="h2">Sorumlu kullanım</h2>
      <p className="caption" style={{ fontSize: 15 }}>
        Down.io yalnızca kendi içeriğiniz veya indirme hakkınız olan içerikler için tasarlanmıştır. Telif hakkı ve
        platform kurallarına uymak size aittir. DRM korumalı akışlar (ör. Spotify tam parçaları) indirilemez; şifreli
        arşivler ve parola korumalı klasörler kullanıcıya bildirilir.
      </p>
    </main>
  );
}
