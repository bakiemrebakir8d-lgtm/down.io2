import { NextResponse } from "next/server";
import { clearScanCache } from "@/lib/server/scan";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function DELETE() {
  return NextResponse.json({ cleared: clearScanCache() });
}
