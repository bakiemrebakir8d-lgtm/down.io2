import { Readable } from "node:stream";
import zlib from "node:zlib";
import { fetchx } from "@/lib/server/http";
import { MIME_BY_EXT, extOf, unb64 } from "@/lib/server/util";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 600;

/** ZIP içindeki tek bir dosyayı (arşivin tamamını indirmeden) Range ile çıkarıp akıtır. */
export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const u = sp.get("u");
  const o = Number(sp.get("o"));
  const c = Number(sp.get("c"));
  const s = Number(sp.get("s"));
  const m = Number(sp.get("m"));
  const n = sp.get("n") || "dosya";
  if (!u || !isFinite(o) || !isFinite(c)) return new Response("Geçersiz istek", { status: 400 });
  const headers = unb64<Record<string, string>>(sp.get("h")) || {};
  const bypass = sp.get("b") === "1";

  try {
    const lh = await fetchx(u, { headers: { ...headers, range: `bytes=${o}-${o + 29}` }, bypass });
    if (lh.status !== 206) return new Response("Kaynak Range desteklemiyor", { status: 502 });
    const buf = Buffer.from(await lh.arrayBuffer());
    if (buf.readUInt32LE(0) !== 0x04034b50) return new Response("Bozuk ZIP kaydı", { status: 502 });
    const start = o + 30 + buf.readUInt16LE(26) + buf.readUInt16LE(28);
    const data = await fetchx(u, {
      headers: { ...headers, range: `bytes=${start}-${start + c - 1}` },
      bypass,
      signal: req.signal,
    });
    if (!data.body) return new Response("Veri yok", { status: 502 });

    const out = new Headers();
    const ext = extOf(n);
    out.set("content-type", MIME_BY_EXT[ext] || "application/octet-stream");
    if (s > 0) out.set("content-length", String(s));
    if (sp.get("d") === "1") {
      out.set("content-disposition", `attachment; filename="${encodeURIComponent(n)}"; filename*=UTF-8''${encodeURIComponent(n)}`);
    }
    const src = Readable.fromWeb(data.body as never);
    const body = m === 8 ? src.pipe(zlib.createInflateRaw()) : src;
    return new Response(Readable.toWeb(body) as unknown as BodyInit, { headers: out });
  } catch (e) {
    return new Response(`Arşiv okunamadı: ${(e as Error).message}`, { status: 502 });
  }
}
