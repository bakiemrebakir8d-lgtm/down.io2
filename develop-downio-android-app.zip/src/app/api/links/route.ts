import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { scannedLinks } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(scannedLinks).orderBy(desc(scannedLinks.lastScannedAt)).limit(500);
  return NextResponse.json(rows);
}

export async function DELETE(req: Request) {
  const sp = new URL(req.url).searchParams;
  if (sp.get("all") === "1") await db.delete(scannedLinks);
  else {
    const id = Number(sp.get("id"));
    if (!id) return NextResponse.json({ error: "id gerekli" }, { status: 400 });
    await db.delete(scannedLinks).where(eq(scannedLinks.id, id));
  }
  return NextResponse.json({ ok: true });
}
