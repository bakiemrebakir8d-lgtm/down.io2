import { fetchx, getText } from "@/lib/server/http";
import { unb64 } from "@/lib/server/util";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 600;

function resolve(base: string, ref: string) {
  return new URL(ref, base).toString();
}

/** HLS (m3u8) akışını parçaları birleştirerek tek .ts dosyası olarak indirtir. */
export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const u = sp.get("u");
  if (!u) return new Response("u gerekli", { status: 400 });
  const headers = unb64<Record<string, string>>(sp.get("h")) || {};
  const bypass = sp.get("b") === "1";
  const name = sp.get("n") || "video.ts";

  let playlistUrl = u;
  let text: string;
  try {
    text = await getText(playlistUrl, { headers, bypass });
    if (text.includes("#EXT-X-STREAM-INF")) {
      // ana liste: en yüksek bant genişliğini seç
      const lines = text.split("\n");
      let best = { bw: -1, url: "" };
      for (let i = 0; i < lines.length; i++) {
        const m = /BANDWIDTH=(\d+)/.exec(lines[i]);
        if (lines[i].startsWith("#EXT-X-STREAM-INF") && m) {
          const next = lines.slice(i + 1).find((l) => l.trim() && !l.startsWith("#"));
          if (next && Number(m[1]) > best.bw) best = { bw: Number(m[1]), url: next.trim() };
        }
      }
      if (!best.url) return new Response("Akış listesi okunamadı", { status: 502 });
      playlistUrl = resolve(playlistUrl, best.url);
      text = await getText(playlistUrl, { headers, bypass });
    }
  } catch (e) {
    return new Response(`Liste alınamadı: ${(e as Error).message}`, { status: 502 });
  }
  if (/#EXT-X-KEY:METHOD=(?!NONE)/.test(text)) {
    return new Response("Bu akış şifreli (DRM/AES) olduğundan indirilemez", { status: 422 });
  }
  const segs = text
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith("#"))
    .map((l) => resolve(playlistUrl, l));
  if (!segs.length) return new Response("Parça bulunamadı", { status: 502 });

  let i = 0;
  const stream = new ReadableStream<Uint8Array>({
    async pull(controller) {
      if (i >= segs.length) return controller.close();
      const url = segs[i++];
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const r = await fetchx(url, { headers, bypass, signal: req.signal, timeout: 30_000 });
          if (!r.ok) throw new Error(`HTTP ${r.status}`);
          controller.enqueue(new Uint8Array(await r.arrayBuffer()));
          return;
        } catch (e) {
          if (attempt === 2) return controller.error(e);
        }
      }
    },
  });
  return new Response(stream, {
    headers: {
      "content-type": "video/mp2t",
      "content-disposition": `attachment; filename="${encodeURIComponent(name)}"; filename*=UTF-8''${encodeURIComponent(name)}`,
      "cache-control": "no-store",
    },
  });
}
