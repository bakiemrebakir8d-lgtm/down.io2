import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { scannedLinks } from "@/db/schema";
import { scanUrl } from "@/lib/server/scan";
import type { ScanOptions } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 180;

export async function POST(req: Request) {
  let body: { url?: string; options?: ScanOptions };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }
  if (!body.url || typeof body.url !== "string") {
    return NextResponse.json({ error: "Bağlantı gerekli" }, { status: 400 });
  }
  try {
    const result = await scanUrl(body.url, body.options || {});
    try {
      await db
        .insert(scannedLinks)
        .values({
          url: result.url,
          platform: result.platform,
          title: result.title.slice(0, 200),
          itemCount: result.items.length,
        })
        .onConflictDoUpdate({
          target: scannedLinks.url,
          set: {
            platform: result.platform,
            title: result.title.slice(0, 200),
            itemCount: result.items.length,
            scanCount: sql`${scannedLinks.scanCount} + 1`,
            lastScannedAt: new Date(),
          },
        });
    } catch {
      /* geçmiş kaydı başarısız olsa da sonuç dönsün */
    }
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message || "Tarama başarısız" }, { status: 502 });
  }
}
