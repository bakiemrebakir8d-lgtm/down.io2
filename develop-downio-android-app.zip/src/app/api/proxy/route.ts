import { fetchx } from "@/lib/server/http";
import { unb64 } from "@/lib/server/util";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function absolutize(base: string, ref: string) {
  try {
    return new URL(ref, base).toString();
  } catch {
    return ref;
  }
}

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const u = sp.get("u");
  if (!u) return new Response("u gerekli", { status: 400 });
  const headers = unb64<Record<string, string>>(sp.get("h")) || {};
  const bypass = sp.get("b") === "1";
  const range = req.headers.get("range");
  if (range) headers.range = range;
  if (!headers.referer) {
    try {
      headers.referer = new URL(u).origin + "/";
    } catch {
      /* yoksay */
    }
  }

  let r;
  try {
    r = await fetchx(u, { headers, bypass, signal: req.signal, timeout: 30_000 });
  } catch (e) {
    return new Response(`Kaynağa ulaşılamadı: ${(e as Error).message}`, { status: 502 });
  }

  const ctype = r.headers.get("content-type") || "";
  // HLS önizleme: parça adreslerini proxy üzerinden geçecek şekilde yeniden yaz
  if (sp.get("pl") === "1" || /mpegurl/i.test(ctype) || /\.m3u8(\?|$)/.test(u)) {
    const text = await r.text();
    if (text.startsWith("#EXTM3U")) {
      const mk = (ref: string) => {
        const abs = absolutize(u, ref);
        const p = new URLSearchParams({ u: abs });
        if (sp.get("h")) p.set("h", sp.get("h") as string);
        if (bypass) p.set("b", "1");
        if (/\.m3u8(\?|$)/.test(abs)) p.set("pl", "1");
        return `/api/proxy?${p}`;
      };
      const out = text
        .split("\n")
        .map((line) => {
          const t = line.trim();
          if (!t) return line;
          if (t.startsWith("#")) return line.replace(/URI="([^"]+)"/g, (_, x) => `URI="${mk(x)}"`);
          return mk(t);
        })
        .join("\n");
      return new Response(out, {
        headers: { "content-type": "application/vnd.apple.mpegurl", "cache-control": "no-store" },
      });
    }
    return new Response(text, { status: r.status, headers: { "content-type": ctype } });
  }

  const out = new Headers();
  for (const k of ["content-type", "content-length", "content-range", "accept-ranges", "last-modified", "etag"]) {
    const v = r.headers.get(k);
    if (v) out.set(k, v);
  }
  if (!out.has("accept-ranges")) out.set("accept-ranges", "bytes");
  out.set("cache-control", "private, max-age=600");
  if (sp.get("d") === "1") {
    const name = sp.get("n") || "down-io-dosya";
    out.set("content-disposition", `attachment; filename="${encodeURIComponent(name)}"; filename*=UTF-8''${encodeURIComponent(name)}`);
  }
  return new Response(r.body as unknown as BodyInit, { status: r.status, headers: out });
}
