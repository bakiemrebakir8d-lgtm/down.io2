import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { downloads } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(downloads).orderBy(desc(downloads.createdAt)).limit(500);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const b = (await req.json()) as {
    title?: string;
    filename?: string;
    kind?: string;
    size?: number | null;
    sourceUrl?: string;
    mediaUrl?: string;
    localId?: string;
    quality?: string;
  };
  if (!b.filename || !b.sourceUrl) return NextResponse.json({ error: "eksik alan" }, { status: 400 });
  const [row] = await db
    .insert(downloads)
    .values({
      title: (b.title || b.filename).slice(0, 300),
      filename: b.filename.slice(0, 300),
      kind: b.kind || "other",
      size: b.size && b.size > 0 ? Math.round(b.size) : null,
      sourceUrl: b.sourceUrl,
      mediaUrl: b.mediaUrl || null,
      localId: b.localId || null,
      quality: b.quality || null,
    })
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(req: Request) {
  const sp = new URL(req.url).searchParams;
  if (sp.get("all") === "1") await db.delete(downloads);
  else {
    const id = Number(sp.get("id"));
    if (!id) return NextResponse.json({ error: "id gerekli" }, { status: 400 });
    await db.delete(downloads).where(eq(downloads.id, id));
  }
  return NextResponse.json({ ok: true });
}
