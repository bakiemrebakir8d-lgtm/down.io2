import { Suspense } from "react";
import { DownloadView } from "@/components/DownloadView";

export default function Page() {
  return (
    <Suspense fallback={null}>
      <DownloadView />
    </Suspense>
  );
}
