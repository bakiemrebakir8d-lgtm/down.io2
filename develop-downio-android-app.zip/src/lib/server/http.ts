import dns from "node:dns";
import net from "node:net";
import { Agent, fetch as ufetch } from "undici";
import type { Response } from "undici";

export const UA_DESKTOP =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
export const UA_MOBILE =
  "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";

export function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return (
      a === 10 ||
      a === 127 ||
      a === 0 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127)
    );
  }
  const l = ip.toLowerCase();
  return (
    l === "::1" ||
    l === "::" ||
    l.startsWith("fc") ||
    l.startsWith("fd") ||
    l.startsWith("fe80") ||
    l.startsWith("::ffff:127.") ||
    l.startsWith("::ffff:10.") ||
    l.startsWith("::ffff:192.168.")
  );
}

/* ---------- DNS-over-HTTPS (Engel aşma) ---------- */
const dohCache = new Map<string, { ips: string[]; exp: number }>();

async function doh(host: string): Promise<string[]> {
  const c = dohCache.get(host);
  if (c && c.exp > Date.now()) return c.ips;
  const endpoints = [
    `https://1.1.1.1/dns-query?name=${encodeURIComponent(host)}&type=A`,
    `https://8.8.8.8/resolve?name=${encodeURIComponent(host)}&type=A`,
  ];
  for (const ep of endpoints) {
    try {
      const r = await ufetch(ep, {
        headers: { accept: "application/dns-json" },
        signal: AbortSignal.timeout(5000),
      });
      const j = (await r.json()) as { Answer?: { type: number; data: string }[] };
      const ips = (j.Answer || []).filter((a) => a.type === 1).map((a) => a.data);
      if (ips.length) {
        dohCache.set(host, { ips, exp: Date.now() + 5 * 60_000 });
        return ips;
      }
    } catch {
      /* sıradaki sağlayıcı */
    }
  }
  return [];
}

function makeAgent(bypass: boolean) {
  const lookup = (hostname: string, options: { all?: boolean }, cb: (...a: unknown[]) => void) => {
    const done = (ips: { address: string; family: number }[]) => {
      const ok = ips.filter((i) => !isPrivateIp(i.address));
      if (!ok.length) return cb(new Error("Engellenen adres"));
      if (options && options.all) cb(null, ok);
      else cb(null, ok[0].address, ok[0].family);
    };
    const system = () =>
      dns.lookup(hostname, { all: true }, (err, addrs) => (err ? cb(err) : done(addrs)));
    if (bypass) {
      doh(hostname).then((ips) =>
        ips.length ? done(ips.map((address) => ({ address, family: 4 }))) : system(),
      );
    } else system();
  };
  return new Agent({
    connect: { lookup } as never,
    headersTimeout: 30_000,
    bodyTimeout: 0,
  });
}

const globalAgents = globalThis as typeof globalThis & {
  __downioAgents?: { normal: Agent; bypass: Agent };
};
function agents() {
  if (!globalAgents.__downioAgents) {
    globalAgents.__downioAgents = { normal: makeAgent(false), bypass: makeAgent(true) };
  }
  return globalAgents.__downioAgents;
}

export interface FxInit {
  headers?: Record<string, string>;
  method?: string;
  body?: string;
  bypass?: boolean;
  timeout?: number;
  signal?: AbortSignal;
  redirect?: "follow" | "manual";
}

export async function fetchx(url: string, init: FxInit = {}): Promise<Response> {
  const u = new URL(url);
  if (!/^https?:$/.test(u.protocol)) throw new Error("Geçersiz protokol");
  const bare = u.hostname.replace(/^\[|\]$/g, "");
  if (net.isIP(bare) && isPrivateIp(bare)) throw new Error("Engellenen adres");

  const headers: Record<string, string> = {
    "user-agent": UA_DESKTOP,
    "accept-language": "en-US,en;q=0.9",
  };
  for (const [k, v] of Object.entries(init.headers || {})) headers[k.toLowerCase()] = v;

  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), init.timeout ?? 25_000);
  init.signal?.addEventListener("abort", () => ac.abort());
  try {
    return await ufetch(url, {
      method: init.method || "GET",
      headers,
      body: init.body,
      redirect: init.redirect || "follow",
      dispatcher: init.bypass ? agents().bypass : agents().normal,
      signal: ac.signal,
    });
  } finally {
    clearTimeout(timer);
  }
}

export async function getText(url: string, init: FxInit = {}): Promise<string> {
  const r = await fetchx(url, init);
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.text();
}

export async function getJson<T = unknown>(url: string, init: FxInit = {}): Promise<T> {
  const r = await fetchx(url, init);
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return (await r.json()) as T;
}
