import type { MediaItem, ScanOptions, ScanResult } from "@/lib/types";
import { scanGeneric } from "./generic";
import { scanGofile } from "./gofile";
import {
  facebookFallback,
  instagramNative,
  scanSpotify,
  tiktokFallback,
  twProfile,
  twTweet,
  youtubeFallback,
} from "./social";
import { type Ctx, cookieFor, headInfo, kindFromExt } from "./util";
import { scanYandex } from "./yandex";
import { ytdlpItems } from "./ytdlp";

const g = globalThis as typeof globalThis & { __scanCache?: Map<string, { at: number; res: ScanResult }> };
const cache = (g.__scanCache ||= new Map());

export function clearScanCache(): number {
  const n = cache.size;
  cache.clear();
  return n;
}

function platformOf(host: string): string {
  if (/gofile\.io$/.test(host)) return "GoFile";
  if (/yandex\.|yadi\.sk/.test(host)) return "Yandex Disk";
  if (/(^|\.)x\.com$|twitter\.com$|^t\.co$/.test(host)) return "X";
  if (/tiktok\.com$/.test(host)) return "TikTok";
  if (/instagram\.com$/.test(host)) return "Instagram";
  if (/facebook\.com$|fb\.watch$|fb\.com$/.test(host)) return "Facebook";
  if (/youtube\.com$|youtu\.be$/.test(host)) return "YouTube";
  if (/spotify\.com$|spotify\.link$/.test(host)) return "Spotify";
  return "Web";
}

function dedupe(items: MediaItem[]): MediaItem[] {
  const seen = new Set<string>();
  return items.filter((i) => {
    const k = i.variants[0]?.src || i.variants[0]?.downloadUrl || i.id;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

async function fillSizes(items: MediaItem[], ctx: Ctx) {
  const jobs: { v: MediaItem["variants"][number] }[] = [];
  for (const it of items) {
    for (const v of it.variants) {
      if (v.size === undefined && v.src && !v.previewUrl.includes("pl=1") && !v.src.includes(".m3u8")) jobs.push({ v });
    }
  }
  const list = jobs.slice(0, 90);
  let idx = 0;
  const worker = async () => {
    while (idx < list.length) {
      const j = list[idx++];
      const info = await headInfo(j.v.src as string, j.v.hdr, ctx.bypass);
      if (info.size) j.v.size = info.size;
    }
  };
  await Promise.race([
    Promise.all(Array.from({ length: 8 }, worker)),
    new Promise((r) => setTimeout(r, 15_000)),
  ]);
  for (const it of items) if (it.size === undefined) it.size = it.variants[0]?.size;
}

export async function scanUrl(raw: string, opts: ScanOptions): Promise<ScanResult> {
  let s = raw.trim();
  if (!/^https?:\/\//i.test(s)) s = "https://" + s;
  let url: URL;
  try {
    url = new URL(s);
  } catch {
    throw new Error("Geçersiz bağlantı");
  }
  const host = url.hostname.replace(/^(www\.|m\.|mobile\.)/, "").toLowerCase();
  const cookie = cookieFor(host, opts.cookies);
  const platform = platformOf(host);
  const key = `${url.toString()}|${cookie || ""}|${opts.password || ""}|${opts.bypass ? 1 : 0}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < 5 * 60_000) return hit.res;

  const ctx: Ctx = { url, cookie, bypass: !!opts.bypass, warnings: [], opts };
  let items: MediaItem[] = [];
  let title = url.hostname;
  let locked: ScanResult["locked"];
  const take = (r: { title: string; items: MediaItem[] } | null | undefined) => {
    if (!r) return false;
    if (r.title) title = r.title;
    items.push(...r.items);
    return r.items.length > 0;
  };
  const safe = async <T>(fn: () => Promise<T>): Promise<T | null> => {
    try {
      return await fn();
    } catch (e) {
      ctx.warnings.push((e as Error).message);
      return null;
    }
  };

  switch (platform) {
    case "GoFile": {
      const r = await scanGofile(ctx);
      title = r.title;
      items = r.items;
      locked = r.locked;
      break;
    }
    case "Yandex Disk": {
      take(await scanYandex(ctx));
      break;
    }
    case "Spotify": {
      take(await scanSpotify(ctx));
      break;
    }
    case "X": {
      const p = url.pathname;
      const tid = /status(?:es)?\/(\d+)/.exec(p)?.[1];
      if (/^\/i\/(broadcasts|spaces)\//.test(p)) take(await safe(() => ytdlpItems(ctx, url.toString())));
      else if (tid) {
        if (!take(await safe(() => twTweet(tid, ctx)))) take(await safe(() => ytdlpItems(ctx, url.toString())));
      } else {
        const u = /^\/([A-Za-z0-9_]{1,15})(?:\/(?:media|with_replies|highlights|likes|videos))?\/?$/.exec(p)?.[1];
        if (u && !/^(home|explore|i|search|settings|notifications|messages|compose)$/.test(u)) take(await safe(() => twProfile(u, ctx)));
        else take(await safe(() => ytdlpItems(ctx, url.toString())));
      }
      break;
    }
    case "TikTok": {
      const single = /\/(video|photo|v)\/|^(vm|vt)\./.test(url.pathname + " " + url.hostname) || /^\/[A-Za-z0-9]{6,12}\/?$/.test(url.pathname);
      if (single) {
        if (!take(await tiktokFallback(ctx))) take(await safe(() => ytdlpItems(ctx, url.toString())));
      } else {
        take(await safe(() => ytdlpItems(ctx, url.toString())));
      }
      break;
    }
    case "Instagram": {
      let ok = false;
      if (cookie) ok = take(await safe(() => instagramNative(ctx)));
      if (!ok) ok = take(await safe(() => ytdlpItems(ctx, url.toString())));
      if (!ok && !cookie) take(await safe(() => instagramNative(ctx)));
      break;
    }
    case "Facebook": {
      if (!take(await safe(() => ytdlpItems(ctx, url.toString())))) take(await safe(() => facebookFallback(ctx)));
      break;
    }
    case "YouTube": {
      if (!take(await safe(() => ytdlpItems(ctx, url.toString())))) take(await safe(() => youtubeFallback(ctx)));
      break;
    }
    default: {
      const direct = kindFromExt(url.pathname.split(".").pop()) !== "other";
      const [gen, yt] = await Promise.all([
        safe(() => scanGeneric(ctx)),
        direct ? Promise.resolve(null) : safe(() => ytdlpItems(ctx, url.toString())),
      ]);
      // Video platformu çıktısı önce gelsin
      if (yt) take(yt);
      if (gen) {
        const t = title;
        take(gen);
        if (yt?.title) title = t;
      }
      const embeds = (ctx as Ctx & { embeds?: string[] }).embeds || [];
      if (!yt && embeds.length) {
        for (const e of embeds) {
          const sub = await safe(() => scanUrl(e, opts));
          if (sub) items.push(...sub.items);
        }
      }
    }
  }

  items = dedupe(items);
  if (!items.length && !locked) {
    ctx.warnings.push("Bu bağlantıda indirilebilir medya bulunamadı. Gizli içerikse Ayarlar → Oturum bölümünden giriş yapmayı deneyin.");
  } else await fillSizes(items, ctx);

  for (const it of items) {
    for (const v of it.variants) {
      delete v.src;
      delete v.hdr;
    }
  }
  const res: ScanResult = { url: url.toString(), platform, title, items, warnings: [...new Set(ctx.warnings)], locked };
  if (items.length) cache.set(key, { at: Date.now(), res });
  return res;
}
