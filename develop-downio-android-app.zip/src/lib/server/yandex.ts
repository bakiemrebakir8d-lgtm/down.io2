import type { MediaItem } from "@/lib/types";
import { fetchx, getText } from "./http";
import {
  type Ctx,
  extOf,
  headInfo,
  kindFromExt,
  kindFromMime,
  mkItem,
  mkVariant,
  proxyUrl,
  uid,
} from "./util";
import { zipItems } from "./zip";

const API = "https://cloud-api.yandex.net/v1/disk/public/resources";

interface YNode {
  type: "dir" | "file";
  name: string;
  path?: string;
  size?: number;
  mime_type?: string;
  media_type?: string;
  file?: string;
  preview?: string;
  _embedded?: { items: YNode[]; total: number };
}

export async function scanYandex(ctx: Ctx): Promise<{ title: string; items: MediaItem[] }> {
  const m = /\/(d|i|a)\/([^/?#]+)((?:\/[^?#]*)?)/.exec(ctx.url.pathname);
  if (!m) throw new Error("Yandex Disk bağlantısı tanınmadı");
  const isShort = /yadi\.sk/.test(ctx.url.hostname);
  const publicKey = isShort
    ? `https://yadi.sk/${m[1]}/${m[2]}`
    : `https://${ctx.url.hostname}/${m[1]}/${m[2]}`;
  const subPath = m[3] ? decodeURIComponent(m[3]).replace(/\/$/, "") : "";
  const headers: Record<string, string> = ctx.cookie ? { cookie: ctx.cookie } : {};

  const items: MediaItem[] = [];
  let title = "Yandex Disk";
  let blocked = 0;
  let budget = 800;

  const api = async (path: string, offset: number): Promise<YNode> => {
    const q = new URLSearchParams({
      public_key: publicKey,
      limit: "200",
      offset: String(offset),
      preview_size: "XXXL",
      preview_crop: "false",
    });
    if (path) q.set("path", path);
    const r = await fetchx(`${API}?${q}`, { headers, bypass: ctx.bypass });
    const j = (await r.json()) as YNode & { message?: string; error?: string };
    if (!r.ok) {
      if (r.status === 404) throw new Error("Yandex Disk bağlantısı bulunamadı veya kaldırılmış");
      throw new Error(j.message || `Yandex Disk hatası (${r.status})`);
    }
    return j;
  };

  const directLink = async (n: YNode): Promise<string | undefined> => {
    if (n.file) return n.file;
    try {
      const q = new URLSearchParams({ public_key: publicKey });
      if (n.path) q.set("path", n.path);
      const r = await fetchx(`${API}/download?${q}`, { headers, bypass: ctx.bypass, timeout: 12_000 });
      if (!r.ok) return undefined;
      const j = (await r.json()) as { href?: string };
      return j.href;
    } catch {
      return undefined;
    }
  };

  const addFile = async (n: YNode, folder: string) => {
    const ext = extOf(n.name);
    let kind = kindFromExt(ext);
    if (kind === "other") kind = kindFromMime(n.mime_type) || (n.media_type === "image" ? "image" : n.media_type === "video" ? "video" : "other");
    const link = await directLink(n);
    const title = n.name.replace(/\.[^.]+$/, "") || n.name;
    if (link) {
      const v = mkVariant({ label: "Orijinal", url: link, title, ext: ext || undefined, size: n.size, bypass: ctx.bypass, headers });
      v.filename = n.name;
      v.downloadUrl = proxyUrl(link, { name: n.name, dl: true, bypass: ctx.bypass, headers });
      items.push(
        mkItem({
          title,
          kind,
          folder,
          size: n.size,
          mime: n.mime_type,
          thumb: n.preview ? proxyUrl(n.preview, { bypass: ctx.bypass, headers }) : undefined,
          variants: [v],
        }),
      );
      if (ext === "zip" && (n.size ?? 0) > 0) {
        const inner = await zipItems(n.name, link, headers, ctx.bypass, n.size, ctx.warnings);
        items.push(...inner.map((i) => ({ ...i, folder: [folder, i.folder].filter(Boolean).join("/") })));
      }
      return;
    }
    // İndirme kapalı: elde ne varsa (önizleme) onu sun
    blocked++;
    if (n.preview) {
      const pv = proxyUrl(n.preview, { bypass: ctx.bypass, headers });
      items.push(
        mkItem({
          title,
          kind: kind === "other" ? "image" : kind,
          folder,
          size: n.size,
          note: "İndirme kapalı — yalnızca önizleme çözünürlüğü alınabilir",
          thumb: pv,
          variants: [
            {
              id: uid(),
              label: "Önizleme",
              ext: "jpg",
              filename: `${title}.jpg`,
              size: undefined,
              previewUrl: pv,
              downloadUrl: proxyUrl(n.preview, { bypass: ctx.bypass, headers, name: `${title}.jpg`, dl: true }),
            },
          ],
        }),
      );
    }
  };

  const walk = async (path: string, folder: string, depth: number) => {
    if (budget <= 0 || depth > 6) return;
    let offset = 0;
    for (;;) {
      const node = await api(path, offset);
      if (depth === 0 && offset === 0) title = node.name || title;
      if (node.type === "file") {
        budget--;
        await addFile(node, folder);
        return;
      }
      const children = node._embedded?.items || [];
      for (const c of children) {
        if (budget <= 0) break;
        if (c.type === "dir") await walk(c.path || `${path}/${c.name}`, [folder, c.name].filter(Boolean).join("/"), depth + 1);
        else {
          budget--;
          await addFile(c, folder);
        }
      }
      offset += children.length;
      if (!children.length || offset >= (node._embedded?.total ?? 0)) break;
    }
  };

  try {
    await walk(subPath, "", 0);
  } catch (e) {
    if (!items.length) {
      // API reddettiyse sayfanın kendi verisinden doğrudan bağlantıları dene
      try {
        const html = await getText(publicKey, { bypass: ctx.bypass, headers });
        const found = new Set<string>();
        for (const mm of html.matchAll(/https?:\\?\/\\?\/(?:downloader|getfile)\.disk\.yandex\.[a-z.]+[^"'\s<>\\]+/g)) {
          found.add(mm[0].replace(/\\\//g, "/").replace(/\\u0026/g, "&"));
        }
        for (const u of [...found].slice(0, 50)) {
          const info = await headInfo(u, headers, ctx.bypass);
          const nm = /filename=([^&]+)/.exec(u)?.[1];
          const name = nm ? decodeURIComponent(nm) : `dosya-${items.length + 1}`;
          const v = mkVariant({ label: "Orijinal", url: u, title: name.replace(/\.[^.]+$/, ""), ext: extOf(name) || undefined, size: info.size, bypass: ctx.bypass, headers });
          items.push(mkItem({ title: name.replace(/\.[^.]+$/, ""), kind: kindFromExt(extOf(name)), variants: [v], size: info.size }));
        }
      } catch {
        /* yoksay */
      }
      if (!items.length) throw e;
    } else {
      ctx.warnings.push((e as Error).message);
    }
  }
  if (blocked) ctx.warnings.push(`${blocked} dosyada indirme kapalı (sahibi kısıtlamış); mümkün olanların önizlemesi listelendi`);
  return { title, items };
}
