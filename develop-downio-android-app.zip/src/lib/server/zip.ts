import type { MediaItem } from "@/lib/types";
import { fetchx } from "./http";
import { extOf, kindFromExt, mkItem, uid, b64, MIME_BY_EXT } from "./util";

export interface ZipEntry {
  name: string;
  method: number;
  csize: number;
  size: number;
  offset: number;
  encrypted: boolean;
}

async function rangeGet(
  url: string,
  headers: Record<string, string> | undefined,
  bypass: boolean,
  range: string,
): Promise<{ buf: Buffer; total?: number }> {
  const r = await fetchx(url, { headers: { ...(headers || {}), range: `bytes=${range}` }, bypass, timeout: 30_000 });
  if (r.status !== 206) {
    r.body?.cancel().catch(() => {});
    throw new Error("Sunucu kısmi (Range) isteği desteklemiyor");
  }
  const cr = r.headers.get("content-range");
  const total = cr ? parseInt(cr.split("/")[1] || "", 10) : undefined;
  return { buf: Buffer.from(await r.arrayBuffer()), total: total && isFinite(total) ? total : undefined };
}

/** Arşivi indirmeden, yalnızca merkezi dizini okuyarak ZIP içeriğini listeler. */
export async function listZip(
  url: string,
  headers: Record<string, string> | undefined,
  bypass: boolean,
  knownSize?: number,
): Promise<ZipEntry[]> {
  let total = knownSize;
  if (!total) total = (await rangeGet(url, headers, bypass, "0-0")).total;
  if (!total) throw new Error("Arşiv boyutu öğrenilemedi");
  const tail = await rangeGet(url, headers, bypass, `${Math.max(0, total - 70000)}-${total - 1}`);
  const buf = tail.buf;
  let e = -1;
  for (let i = buf.length - 22; i >= 0; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      e = i;
      break;
    }
  }
  if (e < 0) throw new Error("ZIP dizini bulunamadı");
  const tailStart = Math.max(0, total - 70000);
  let endAbs = tailStart + e; // merkezi dizinin bittiği konum
  let count = buf.readUInt16LE(e + 10);
  let cdSize = buf.readUInt32LE(e + 12);
  let cdOff = buf.readUInt32LE(e + 16);

  if ((cdOff === 0xffffffff || cdSize === 0xffffffff || count === 0xffff) && e >= 20) {
    if (buf.readUInt32LE(e - 20) === 0x07064b50) {
      const z64 = Number(buf.readBigUInt64LE(e - 20 + 8));
      endAbs = z64;
      const z = (await rangeGet(url, headers, bypass, `${z64}-${z64 + 55}`)).buf;
      count = Number(z.readBigUInt64LE(32));
      cdSize = Number(z.readBigUInt64LE(40));
      cdOff = Number(z.readBigUInt64LE(48));
    }
  }
  if (cdSize > 48 * 1024 * 1024 || cdSize === 0) throw new Error("ZIP dizini okunamadı");
  // Dosya başında ön ek (ör. shebang) varsa ofsetler kayar; gerçek konumu sondan hesapla
  const realCd = endAbs - cdSize;
  const prefix = realCd >= cdOff ? realCd - cdOff : 0;
  const cd = (await rangeGet(url, headers, bypass, `${realCd}-${realCd + cdSize - 1}`)).buf;

  const out: ZipEntry[] = [];
  let p = 0;
  while (p + 46 <= cd.length && cd.readUInt32LE(p) === 0x02014b50 && out.length < 5000) {
    const flags = cd.readUInt16LE(p + 8);
    const method = cd.readUInt16LE(p + 10);
    let csize = cd.readUInt32LE(p + 20);
    let size = cd.readUInt32LE(p + 24);
    const nl = cd.readUInt16LE(p + 28);
    const el = cd.readUInt16LE(p + 30);
    const cl = cd.readUInt16LE(p + 32);
    let offset = cd.readUInt32LE(p + 42);
    const nameBuf = cd.subarray(p + 46, p + 46 + nl);
    let name = nameBuf.toString("utf8");
    if (!(flags & 0x800) && name.includes("\ufffd")) name = nameBuf.toString("latin1");
    // zip64 ek alanı
    let x = p + 46 + nl;
    const xEnd = x + el;
    while (x + 4 <= xEnd) {
      const id = cd.readUInt16LE(x);
      const len = cd.readUInt16LE(x + 2);
      if (id === 1) {
        let q = x + 4;
        if (size === 0xffffffff) { size = Number(cd.readBigUInt64LE(q)); q += 8; }
        if (csize === 0xffffffff) { csize = Number(cd.readBigUInt64LE(q)); q += 8; }
        if (offset === 0xffffffff) { offset = Number(cd.readBigUInt64LE(q)); q += 8; }
      }
      x += 4 + len;
    }
    offset += prefix;
    if (!name.endsWith("/")) out.push({ name, method, csize, size, offset, encrypted: !!(flags & 1) });
    p += 46 + nl + el + cl;
  }
  return out;
}

export function zipEntryUrl(
  src: string,
  e: ZipEntry,
  headers: Record<string, string> | undefined,
  bypass: boolean,
  dl: boolean,
): string {
  const p = new URLSearchParams({
    u: src,
    o: String(e.offset),
    c: String(e.csize),
    s: String(e.size),
    m: String(e.method),
    n: e.name.split("/").pop() || e.name,
  });
  if (headers && Object.keys(headers).length) p.set("h", b64(headers));
  if (bypass) p.set("b", "1");
  if (dl) p.set("d", "1");
  return `/api/zip?${p.toString()}`;
}

export async function zipItems(
  archiveName: string,
  src: string,
  headers: Record<string, string> | undefined,
  bypass: boolean,
  size: number | undefined,
  warnings: string[],
): Promise<MediaItem[]> {
  try {
    const entries = await listZip(src, headers, bypass, size);
    const items: MediaItem[] = [];
    for (const e of entries.slice(0, 1500)) {
      const base = e.name.split("/").pop() || e.name;
      if (base.startsWith(".") || base.startsWith("__")) continue;
      const ext = extOf(base);
      const kind = kindFromExt(ext);
      const folder = [archiveName, ...e.name.split("/").slice(0, -1)].join("/");
      if (e.encrypted) {
        warnings.push(`"${base}" şifreli, atlandı`);
        continue;
      }
      if (e.method !== 0 && e.method !== 8) continue;
      items.push(
        mkItem({
          title: base.replace(/\.[^.]+$/, ""),
          kind,
          folder,
          size: e.size,
          mime: MIME_BY_EXT[ext],
          variants: [
            {
              id: uid(),
              label: "Orijinal",
              ext: ext || "bin",
              size: e.size,
              filename: base,
              previewUrl: zipEntryUrl(src, e, headers, bypass, false),
              downloadUrl: zipEntryUrl(src, e, headers, bypass, true),
            },
          ],
        }),
      );
    }
    return items;
  } catch (err) {
    warnings.push(`"${archiveName}" arşivi taranamadı: ${(err as Error).message}`);
    return [];
  }
}
