import { execFile, spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import type { MediaItem, Variant } from "@/lib/types";
import { fetchx } from "./http";
import { type Ctx, extOf, kindFromExt, mkItem, mkVariant, proxyUrl, sanitize, uid } from "./util";

const g = globalThis as typeof globalThis & { __ytdlpBin?: Promise<string | null> };

function works(bin: string): boolean {
  try {
    const r = spawnSync(bin, ["--version"], { timeout: 20_000 });
    return r.status === 0;
  } catch {
    return false;
  }
}

async function resolveBin(): Promise<string | null> {
  const candidates = [
    process.env.YTDLP_PATH,
    path.join(process.cwd(), "bin", "yt-dlp"),
    path.join(os.tmpdir(), "downio", "yt-dlp"),
    "yt-dlp",
  ].filter(Boolean) as string[];
  for (const c of candidates) if (works(c)) return c;
  // Yoksa resmi yt-dlp dosyasını (Python zipapp) indir
  try {
    const dir = path.join(os.tmpdir(), "downio");
    fs.mkdirSync(dir, { recursive: true });
    const target = path.join(dir, "yt-dlp");
    const r = await fetchx("https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp", { timeout: 120_000 });
    if (!r.ok) return null;
    fs.writeFileSync(target, Buffer.from(await r.arrayBuffer()));
    fs.chmodSync(target, 0o755);
    return works(target) ? target : null;
  } catch {
    return null;
  }
}

function bin(): Promise<string | null> {
  if (!g.__ytdlpBin) g.__ytdlpBin = resolveBin().then((b) => (b ? b : ((g.__ytdlpBin = undefined), null)));
  return g.__ytdlpBin;
}

type Fmt = {
  url?: string;
  ext?: string;
  height?: number;
  width?: number;
  vcodec?: string;
  acodec?: string;
  protocol?: string;
  filesize?: number;
  filesize_approx?: number;
  format_note?: string;
  abr?: number;
  tbr?: number;
  fps?: number;
  http_headers?: Record<string, string>;
  format_id?: string;
};

type Info = {
  title?: string;
  id?: string;
  thumbnail?: string;
  duration?: number;
  width?: number;
  height?: number;
  formats?: Fmt[];
  url?: string;
  ext?: string;
  entries?: (Info | null)[];
  http_headers?: Record<string, string>;
  webpage_url?: string;
  extractor_key?: string;
  _type?: string;
};

export async function runYtdlp(ctx: Ctx, url: string, timeoutMs = 100_000): Promise<Info | null> {
  const b = await bin();
  if (!b) return null;
  const args = [
    "-J",
    "--no-warnings",
    "--skip-download",
    "--ignore-errors",
    "--playlist-end",
    "20",
    "--socket-timeout",
    "20",
    "--no-cache-dir",
  ];
  if (ctx.cookie) args.push("--add-header", `Cookie:${ctx.cookie}`);
  args.push("--", url);
  return new Promise((resolve) => {
    execFile(b, args, { maxBuffer: 128 * 1024 * 1024, timeout: timeoutMs }, (err, stdout) => {
      if (!stdout) return resolve(null);
      try {
        resolve(JSON.parse(stdout) as Info);
      } catch {
        resolve(null);
      }
      void err;
    });
  });
}

function fromInfo(info: Info, ctx: Ctx, folder?: string): MediaItem[] {
  if (info.entries) {
    const f = info.title || folder;
    return info.entries.filter(Boolean).flatMap((e) => fromInfo(e as Info, ctx, f));
  }
  const title = sanitize(info.title || info.id || "video") || "video";
  const fmts = (info.formats || []).filter((f) => f.url && f.protocol !== "mhtml" && f.ext !== "mhtml");
  const hdrOf = (f: Fmt) => {
    const h: Record<string, string> = {};
    for (const [k, v] of Object.entries({ ...(info.http_headers || {}), ...(f.http_headers || {}) })) {
      if (/^(user-agent|referer|cookie|origin|accept)$/i.test(k)) h[k.toLowerCase()] = String(v);
    }
    if (ctx.cookie && !h.cookie) h.cookie = ctx.cookie;
    return h;
  };
  const isHttp = (f: Fmt) => /^https?$/.test(f.protocol || "https");
  const isHls = (f: Fmt) => (f.protocol || "").startsWith("m3u8");
  const hasV = (f: Fmt) => !!f.vcodec && f.vcodec !== "none";
  const hasA = (f: Fmt) => !!f.acodec && f.acodec !== "none";

  const mk = (f: Fmt, audioOnly = false): Variant => {
    const hls = isHls(f);
    const size = f.filesize || f.filesize_approx;
    const label = audioOnly
      ? `${f.abr ? Math.round(f.abr) + " kbps" : f.format_note || "Ses"}`
      : f.height
        ? `${f.height}p${f.fps && f.fps > 30 ? Math.round(f.fps) : ""}`
        : f.format_note || "Orijinal";
    return mkVariant({
      label,
      url: f.url as string,
      title,
      ext: hls ? "ts" : f.ext || extOf(f.url as string) || undefined,
      size,
      height: f.height,
      hls,
      headers: hdrOf(f),
      bypass: ctx.bypass,
      audioOnly,
    });
  };

  const items: MediaItem[] = [];
  const thumb = info.thumbnail ? proxyUrl(info.thumbnail, { bypass: ctx.bypass }) : undefined;

  let vids = fmts.filter((f) => hasV(f) && hasA(f) && isHttp(f));
  if (!vids.length) vids = fmts.filter((f) => hasV(f) && hasA(f) && isHls(f));
  if (!vids.length) vids = fmts.filter((f) => hasV(f) && !hasA(f) && isHttp(f)).slice(-3);
  if (!vids.length && info.url) {
    vids = [{ url: info.url, ext: info.ext, height: info.height, vcodec: "x", acodec: "x", protocol: "https", http_headers: info.http_headers }];
  }
  // aynı yüksekliği tekrarlama
  const seen = new Set<string>();
  const uniq = vids
    .sort((a, b) => (b.height || 0) - (a.height || 0) || (b.tbr || 0) - (a.tbr || 0))
    .filter((f) => {
      const k = `${f.height}-${f.ext}-${isHls(f)}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  if (uniq.length) {
    const variants = uniq.map((f) => mk(f));
    const only = uniq.every((f) => hasV(f) && !hasA(f));
    items.push(
      mkItem({
        title,
        kind: kindFromExt(variants[0].ext) === "image" ? "image" : kindFromExt(variants[0].ext) === "audio" ? "audio" : "video",
        thumb,
        duration: info.duration,
        width: info.width,
        height: info.height,
        folder,
        note: only ? "Bu kaynak ses ve görüntüyü ayrı sunuyor; ses ayrı dosya olarak listelenir" : undefined,
        variants,
      }),
    );
  }
  const audios = fmts
    .filter((f) => hasA(f) && !hasV(f) && isHttp(f))
    .sort((a, b) => (b.abr || b.tbr || 0) - (a.abr || a.tbr || 0));
  if (audios.length && (items.length || !uniq.length)) {
    const best = audios.slice(0, 2).map((f) => mk(f, true));
    items.push(
      mkItem({
        title: `${title} (ses)`,
        kind: "audio",
        thumb,
        duration: info.duration,
        folder,
        variants: best,
      }),
    );
  }
  void uid;
  return items;
}

export async function ytdlpItems(ctx: Ctx, url: string): Promise<{ title: string; items: MediaItem[] } | null> {
  const info = await runYtdlp(ctx, url);
  if (!info) return null;
  const items = fromInfo(info, ctx);
  if (!items.length) return null;
  return { title: info.title || "", items };
}
