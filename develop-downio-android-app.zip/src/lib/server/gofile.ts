import crypto from "node:crypto";
import vm from "node:vm";
import type { MediaItem } from "@/lib/types";
import { fetchx, UA_DESKTOP } from "./http";
import { type Ctx, extOf, kindFromExt, kindFromMime, mkItem, mkVariant, proxyUrl, uid } from "./util";

const UA = UA_DESKTOP;
const LANG = "en-US";

const g = globalThis as typeof globalThis & {
  __gfScript?: { code: string; at: number };
  __gfAccount?: { token: string; at: number };
};

async function loadScript(force = false): Promise<string> {
  const c = g.__gfScript;
  if (!force && c && Date.now() - c.at < 30 * 60_000) return c.code;
  const r = await fetchx("https://gofile.io/js/wt.obf.js", { headers: { "user-agent": UA } });
  if (!r.ok) throw new Error("GoFile betiği alınamadı");
  const code = await r.text();
  g.__gfScript = { code, at: Date.now() };
  return code;
}

/** GoFile'ın kendi (sürekli değişen) betiğini izole bir VM içinde çalıştırıp X-Website-Token üretir. */
async function websiteToken(token: string, force = false): Promise<string> {
  const code = await loadScript(force);
  const ctx: Record<string, unknown> = {
    navigator: { userAgent: UA, language: LANG },
    Date,
    Math,
    console: { log() {}, warn() {}, error() {} },
    TextEncoder,
    TextDecoder,
    crypto: crypto.webcrypto,
  };
  ctx.window = ctx;
  ctx.self = ctx;
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  vm.runInContext(code, ctx, { timeout: 3000 });
  const fn = ctx.generateWT as ((t: string) => unknown) | undefined;
  if (typeof fn !== "function") throw new Error("GoFile token üretilemedi");
  return String(await fn(token));
}

async function guestToken(bypass: boolean, force = false): Promise<string> {
  const a = g.__gfAccount;
  if (!force && a && Date.now() - a.at < 3 * 3600_000) return a.token;
  const r = await fetchx("https://api.gofile.io/accounts", {
    method: "POST",
    headers: { "user-agent": UA, origin: "https://gofile.io", referer: "https://gofile.io/" },
    bypass,
  });
  const j = (await r.json()) as { status: string; data?: { token: string } };
  if (j.status !== "ok" || !j.data?.token) throw new Error(`GoFile hesabı açılamadı (${j.status})`);
  g.__gfAccount = { token: j.data.token, at: Date.now() };
  return j.data.token;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

interface GfResp {
  status: string;
  data?: Record<string, unknown>;
}

async function call(path: string, state: { token: string }, bypass: boolean): Promise<GfResp> {
  let refreshed = false;
  for (let attempt = 0; attempt < 4; attempt++) {
    const wt = await websiteToken(state.token, refreshed);
    const r = await fetchx(`https://api.gofile.io/${path}`, {
      headers: {
        "user-agent": UA,
        authorization: `Bearer ${state.token}`,
        "x-website-token": wt,
        "x-bl": LANG,
        origin: "https://gofile.io",
        referer: "https://gofile.io/",
      },
      bypass,
    });
    let j: GfResp;
    try {
      j = (await r.json()) as GfResp;
    } catch {
      j = { status: `error-http-${r.status}` };
    }
    if (j.status === "error-rateLimit" || r.status === 429) {
      await sleep(2500 * (attempt + 1));
      continue;
    }
    if (j.status === "error-notPremium" && !refreshed) {
      refreshed = true;
      g.__gfScript = undefined;
      state.token = await guestToken(bypass, true);
      continue;
    }
    return j;
  }
  return { status: "error-rateLimit" };
}

interface GfNode {
  id: string;
  type: "file" | "folder";
  name: string;
  size?: number;
  mimetype?: string;
  link?: string;
  thumbnail?: string;
  childrenCount?: number;
  children?: Record<string, GfNode>;
  password?: boolean;
  passwordStatus?: string;
}

type ListRes = { status: "ok"; meta: GfNode; kids: GfNode[] } | { status: string; meta?: undefined; kids?: undefined };

async function list(id: string, state: { token: string }, pw: string | undefined, bypass: boolean): Promise<ListRes> {
  const kids: GfNode[] = [];
  let meta: GfNode | undefined;
  for (let page = 1; page <= 30; page++) {
    const q = `contents/${id}?contentFilter=&page=${page}&pageSize=1000&sortField=name&sortDirection=1${pw ? `&password=${pw}` : ""}`;
    const j = await call(q, state, bypass);
    if (j.status !== "ok" || !j.data) return { status: j.status };
    const d = j.data as unknown as GfNode;
    meta = meta || d;
    const ch = Object.values(d.children || {});
    kids.push(...ch);
    if (ch.length < 1000 || kids.length >= (d.childrenCount ?? Infinity)) break;
  }
  if (!meta) return { status: "error-empty" };
  return { status: "ok", meta, kids };
}

export async function scanGofile(ctx: Ctx): Promise<{ title: string; items: MediaItem[]; locked?: "password" }> {
  const id = /\/d\/([A-Za-z0-9-]+)/.exec(ctx.url.pathname)?.[1];
  if (!id) throw new Error("GoFile bağlantısı geçersiz (/d/<kod> bekleniyor)");
  const pw = ctx.opts.password ? crypto.createHash("sha256").update(ctx.opts.password).digest("hex") : undefined;
  const state = { token: ctx.cookie?.trim() || (await guestToken(ctx.bypass)) };

  const items: MediaItem[] = [];
  let rootTitle = "GoFile";
  let locked = false;
  let counter = 0;

  const dlHeaders = () => ({ cookie: `accountToken=${state.token}`, referer: "https://gofile.io/", "user-agent": UA });

  const pushFile = (n: GfNode, folder: string) => {
    if (!n.link) {
      ctx.warnings.push(`"${n.name}" için indirme bağlantısı verilmedi (soğuk depolama veya sunucu yoğun olabilir)`);
      return;
    }
    const ext = extOf(n.name) || extOf(n.link);
    const kind = kindFromExt(ext) !== "other" ? kindFromExt(ext) : kindFromMime(n.mimetype) || "other";
    const title = n.name.replace(/\.[^.]+$/, "") || n.name;
    const v = mkVariant({
      label: "Orijinal",
      url: n.link,
      title,
      ext: ext || "bin",
      size: n.size,
      headers: dlHeaders(),
      bypass: ctx.bypass,
    });
    v.filename = n.name;
    v.downloadUrl = proxyUrl(n.link, { headers: dlHeaders(), bypass: ctx.bypass, name: n.name, dl: true });
    items.push(
      mkItem({
        title,
        kind,
        folder,
        mime: n.mimetype,
        size: n.size,
        thumb: n.thumbnail ? proxyUrl(n.thumbnail, { headers: dlHeaders(), bypass: ctx.bypass }) : undefined,
        variants: [v],
      }),
    );
  };

  const walk = async (folderId: string, path: string, depth: number, password?: string) => {
    if (depth > 8 || counter > 300) return;
    counter++;
    if (counter > 1) await sleep(350);
    const res = await list(folderId, state, password, ctx.bypass);
    if (res.status !== "ok" || !res.meta || !res.kids) {
      if (res.status === "error-passwordRequired" || res.status === "error-passwordWrong") {
        if (depth === 0) locked = true;
        ctx.warnings.push(
          res.status === "error-passwordWrong"
            ? "Klasör şifresi yanlış"
            : `"${path || "Klasör"}" şifre korumalı — şifreyi girerek tekrar tarayın`,
        );
      } else if (res.status === "error-notFound") {
        throw new Error("GoFile içeriği bulunamadı (silinmiş veya süresi dolmuş olabilir)");
      } else if (res.status === "error-notPublic") {
        ctx.warnings.push(`"${path || "Klasör"}" herkese açık değil`);
      } else {
        throw new Error(`GoFile hatası: ${res.status}`);
      }
      return;
    }
    const { meta, kids } = res;
    if (depth === 0) rootTitle = meta.name || "GoFile";
    if (meta.type === "file") {
      pushFile(meta, path);
      return;
    }
    if (depth === 0 && meta.password && meta.passwordStatus && meta.passwordStatus !== "passwordOk") {
      locked = true;
      ctx.warnings.push("Bu klasör şifre korumalı");
      return;
    }
    for (const k of kids) {
      if (k.type === "folder") await walk(k.id, [path, k.name].filter(Boolean).join("/"), depth + 1, password);
      else pushFile(k, path);
    }
  };

  await walk(id, "", 0, pw);
  void uid;
  return { title: rootTitle, items, locked: locked && !items.length ? "password" : undefined };
}
