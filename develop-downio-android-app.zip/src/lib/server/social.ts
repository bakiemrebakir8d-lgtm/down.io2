import type { MediaItem } from "@/lib/types";
import { fetchx, getJson, getText, UA_DESKTOP, UA_MOBILE } from "./http";
import { type Ctx, extOf, mkItem, mkVariant, proxyUrl, sanitize, unescapeJs } from "./util";

/* =====================================================================
 *  X (Twitter)
 * ===================================================================== */
const TW_BEARER =
  "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";

const TW_FEATURES: Record<string, boolean> = {
  responsive_web_graphql_exclude_directive_enabled: true,
  verified_phone_label_enabled: false,
  creator_subscriptions_tweet_preview_api_enabled: true,
  responsive_web_graphql_timeline_navigation_enabled: true,
  responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
  tweetypie_unmention_optimization_enabled: true,
  responsive_web_edit_tweet_api_enabled: true,
  graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
  view_counts_everywhere_api_enabled: true,
  longform_notetweets_consumption_enabled: true,
  responsive_web_twitter_article_tweet_consumption_enabled: true,
  tweet_awards_web_tipping_enabled: false,
  freedom_of_speech_not_reach_fetch_enabled: true,
  standardized_nudges_misinfo: true,
  tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
  longform_notetweets_rich_text_read_enabled: true,
  longform_notetweets_inline_media_enabled: true,
  responsive_web_enhance_cards_enabled: false,
  hidden_profile_subscriptions_enabled: true,
  rweb_tipjar_consumption_enabled: true,
  highlights_tweets_tab_ui_enabled: true,
  profile_label_improvements_pcf_label_in_post_enabled: true,
};

type TwMedia = {
  type: string;
  media_url_https: string;
  id_str?: string;
  original_info?: { width: number; height: number };
  video_info?: { duration_millis?: number; variants: { bitrate?: number; content_type: string; url: string }[] };
};

function twToken(id: string): string {
  return ((Number(id) / 1e15) * Math.PI).toString(36).replace(/(0+|\.)/g, "");
}

function twMediaToItem(m: TwMedia, title: string, ctx: Ctx): MediaItem | null {
  const thumb = proxyUrl(m.media_url_https, { bypass: ctx.bypass });
  if (m.type === "photo") {
    const ext = extOf(m.media_url_https) || "jpg";
    const clean = m.media_url_https.replace(/\.(jpg|jpeg|png|webp)$/i, "");
    const orig = `${clean}?format=${ext}&name=orig`;
    const v = mkVariant({ label: "Orijinal", url: orig, title, ext, bypass: ctx.bypass });
    return mkItem({ title, kind: "image", thumb, width: m.original_info?.width, height: m.original_info?.height, variants: [v] });
  }
  const mp4 = (m.video_info?.variants || [])
    .filter((v) => v.content_type === "video/mp4")
    .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
  if (!mp4.length) return null;
  const variants = mp4.map((v) => {
    const h = /\/(\d+)x(\d+)\//.exec(v.url);
    const height = h ? Math.min(parseInt(h[1], 10), parseInt(h[2], 10)) : undefined;
    return mkVariant({
      label: m.type === "animated_gif" ? "GIF (mp4)" : height ? `${height}p` : "Orijinal",
      url: v.url,
      title,
      ext: "mp4",
      height,
      bypass: ctx.bypass,
    });
  });
  return mkItem({
    title,
    kind: "video",
    thumb,
    duration: m.video_info?.duration_millis ? m.video_info.duration_millis / 1000 : undefined,
    width: m.original_info?.width,
    height: m.original_info?.height,
    variants,
  });
}

export async function twTweet(id: string, ctx: Ctx): Promise<{ title: string; items: MediaItem[] }> {
  const j = await getJson<{ mediaDetails?: TwMedia[]; text?: string; user?: { screen_name: string } }>(
    `https://cdn.syndication.twimg.com/tweet-result?id=${id}&lang=en&token=${twToken(id)}`,
    { bypass: ctx.bypass },
  );
  const handle = j.user?.screen_name || "x";
  const base = sanitize((j.text || "").replace(/https?:\/\/t\.co\/\w+/g, ""), 60) || `${handle} ${id}`;
  const items: MediaItem[] = [];
  (j.mediaDetails || []).forEach((m, i) => {
    const it = twMediaToItem(m, `${handle}_${id}${(j.mediaDetails || []).length > 1 ? `_${i + 1}` : ""}`, ctx);
    if (it) items.push(it);
  });
  return { title: base, items };
}

function twHeaders(ctx: Ctx, guest?: string): Record<string, string> {
  const h: Record<string, string> = {
    authorization: `Bearer ${TW_BEARER}`,
    "content-type": "application/json",
    "x-twitter-active-user": "yes",
    "x-twitter-client-language": "en",
    "user-agent": UA_DESKTOP,
  };
  if (ctx.cookie) {
    h.cookie = ctx.cookie;
    const ct0 = /ct0=([^;]+)/.exec(ctx.cookie)?.[1];
    if (ct0) h["x-csrf-token"] = ct0;
    h["x-twitter-auth-type"] = "OAuth2Session";
  } else if (guest) h["x-guest-token"] = guest;
  return h;
}

const gt = globalThis as typeof globalThis & {
  __twQ?: { at: number; map: Record<string, string> };
  __twGuest?: { at: number; token: string };
};

async function twQids(ctx: Ctx): Promise<Record<string, string>> {
  if (gt.__twQ && Date.now() - gt.__twQ.at < 6 * 3600_000) return gt.__twQ.map;
  const map: Record<string, string> = { UserByScreenName: "xmU6X_CKVnQ5lSrCbAmJsg", UserMedia: "vFPc2LVIu7so2uA_gHQAdg" };
  try {
    const html = await getText("https://x.com/", { bypass: ctx.bypass, headers: { "user-agent": UA_DESKTOP } });
    const js = /https:\/\/abs\.twimg\.com\/responsive-web\/client-web(?:-legacy)?\/main\.[a-z0-9]+\.js/.exec(html)?.[0];
    if (js) {
      const code = await getText(js, { bypass: ctx.bypass, timeout: 40_000 });
      for (const m of code.matchAll(/queryId:"([^"]+)",operationName:"(\w+)"/g)) map[m[2]] = m[1];
    }
  } catch {
    /* varsayılan kimlikler */
  }
  gt.__twQ = { at: Date.now(), map };
  return map;
}

async function twGuest(ctx: Ctx): Promise<string | undefined> {
  if (gt.__twGuest && Date.now() - gt.__twGuest.at < 3600_000) return gt.__twGuest.token;
  try {
    const r = await fetchx("https://api.x.com/1.1/guest/activate.json", {
      method: "POST",
      headers: { authorization: `Bearer ${TW_BEARER}` },
      bypass: ctx.bypass,
    });
    const j = (await r.json()) as { guest_token?: string };
    if (j.guest_token) gt.__twGuest = { at: Date.now(), token: j.guest_token };
    return j.guest_token;
  } catch {
    return undefined;
  }
}

async function twGql(op: string, vars: unknown, ctx: Ctx): Promise<unknown> {
  const qids = await twQids(ctx);
  const guest = ctx.cookie ? undefined : await twGuest(ctx);
  const feats: Record<string, boolean> = { ...TW_FEATURES };
  for (let attempt = 0; attempt < 3; attempt++) {
    const url = `https://x.com/i/api/graphql/${qids[op]}/${op}?variables=${encodeURIComponent(JSON.stringify(vars))}&features=${encodeURIComponent(JSON.stringify(feats))}&fieldToggles=${encodeURIComponent(JSON.stringify({ withArticlePlainText: false }))}`;
    const r = await fetchx(url, { headers: twHeaders(ctx, guest), bypass: ctx.bypass });
    const t = await r.text();
    if (r.status === 400) {
      const m = /features cannot be null: ([\w, ]+)/.exec(t);
      if (m) {
        m[1].split(",").forEach((f) => (feats[f.trim()] = false));
        continue;
      }
    }
    if (!r.ok) throw new Error(`X API ${r.status}`);
    return JSON.parse(t);
  }
  throw new Error("X API isteği başarısız");
}

type Found = { m: TwMedia; tweetId?: string };

function walkTw(o: unknown, out: Map<string, Found>, depth = 0, tweetId?: string) {
  if (!o || typeof o !== "object" || depth > 40) return;
  if (Array.isArray(o)) return o.forEach((x) => walkTw(x, out, depth + 1, tweetId));
  const rec = o as Record<string, unknown>;
  const ext = rec.extended_entities as { media?: TwMedia[] } | undefined;
  const tid = (typeof rec.id_str === "string" && ext ? rec.id_str : tweetId) as string | undefined;
  if (ext?.media) for (const m of ext.media) out.set(m.id_str || m.media_url_https, { m, tweetId: tid });
  for (const v of Object.values(rec)) walkTw(v, out, depth + 1, tid);
}

function findCursor(o: unknown, depth = 0): string | undefined {
  if (!o || typeof o !== "object" || depth > 40) return undefined;
  const rec = o as Record<string, unknown>;
  if (rec.cursorType === "Bottom" && typeof rec.value === "string") return rec.value;
  for (const v of Object.values(rec)) {
    const f = findCursor(v, depth + 1);
    if (f) return f;
  }
  return undefined;
}

export async function twProfile(username: string, ctx: Ctx): Promise<{ title: string; items: MediaItem[] }> {
  const found = new Map<string, Found>();
  try {
    const u = (await twGql("UserByScreenName", { screen_name: username, withSafetyModeUserFields: true }, ctx)) as {
      data?: { user?: { result?: { rest_id?: string } } };
    };
    const uid = u.data?.user?.result?.rest_id;
    if (!uid) throw new Error("Kullanıcı bulunamadı");
    let cursor: string | undefined;
    for (let page = 0; page < 12; page++) {
      const j = await twGql(
        "UserMedia",
        { userId: uid, count: 40, includePromotedContent: false, withClientEventToken: false, withBirdwatchNotes: false, withVoice: true, withV2Timeline: true, ...(cursor ? { cursor } : {}) },
        ctx,
      );
      const before = found.size;
      walkTw(j, found);
      const next = findCursor(j);
      if (!next || next === cursor || found.size === before) break;
      cursor = next;
    }
  } catch (e) {
    ctx.warnings.push(`X galeri API: ${(e as Error).message}${ctx.cookie ? "" : " — tam galeri için Ayarlar → Oturum bölümünden X girişi yapın"}`);
  }
  if (!found.size) {
    try {
      const html = await getText(`https://syndication.twitter.com/srv/timeline-profile/screen-name/${username}`, {
        bypass: ctx.bypass,
        headers: { "user-agent": UA_MOBILE },
      });
      const data = /<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/.exec(html)?.[1];
      if (data) walkTw(JSON.parse(data), found);
    } catch {
      /* yoksay */
    }
  }
  const items: MediaItem[] = [];
  let n = 0;
  for (const { m, tweetId } of found.values()) {
    n++;
    const it = twMediaToItem(m, `${username}_${tweetId || m.id_str || n}`, ctx);
    if (it) items.push(it);
  }
  return { title: `@${username}`, items };
}

/* =====================================================================
 *  TikTok (tikwm yedek)
 * ===================================================================== */
export async function tiktokFallback(ctx: Ctx): Promise<{ title: string; items: MediaItem[] } | null> {
  try {
    const r = await fetchx("https://www.tikwm.com/api/", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded", "user-agent": UA_MOBILE },
      body: `url=${encodeURIComponent(ctx.url.toString())}&hd=1`,
      bypass: ctx.bypass,
    });
    const j = (await r.json()) as {
      code: number;
      data?: {
        id?: string; title?: string; play?: string; hdplay?: string; wmplay?: string; music?: string;
        cover?: string; duration?: number; size?: number; hd_size?: number; images?: string[];
        author?: { unique_id?: string };
      };
    };
    const d = j.data;
    if (j.code !== 0 || !d) return null;
    const title = sanitize(d.title || "", 70) || `tiktok_${d.id}`;
    const thumb = d.cover ? proxyUrl(d.cover, { bypass: ctx.bypass }) : undefined;
    const items: MediaItem[] = [];
    if (d.images?.length) {
      d.images.forEach((u, i) =>
        items.push(mkItem({ title: `${title} ${i + 1}`, kind: "image", thumb: proxyUrl(u, { bypass: ctx.bypass }), variants: [mkVariant({ label: "Orijinal", url: u, title: `${title} ${i + 1}`, ext: "jpg", bypass: ctx.bypass })] })),
      );
    } else {
      const variants = [];
      if (d.hdplay) variants.push(mkVariant({ label: "HD", url: d.hdplay, title, ext: "mp4", height: 1080, size: d.hd_size, bypass: ctx.bypass }));
      if (d.play) variants.push(mkVariant({ label: "SD", url: d.play, title, ext: "mp4", height: 720, size: d.size, bypass: ctx.bypass }));
      if (variants.length) items.push(mkItem({ title, kind: "video", thumb, duration: d.duration, variants }));
    }
    if (d.music) items.push(mkItem({ title: `${title} (müzik)`, kind: "audio", thumb, variants: [mkVariant({ label: "Orijinal", url: d.music, title: `${title} müzik`, ext: "mp3", audioOnly: true, bypass: ctx.bypass })] }));
    return items.length ? { title, items } : null;
  } catch {
    return null;
  }
}

/* =====================================================================
 *  Instagram
 * ===================================================================== */
const IG_APP = "936619743392459";

function igHeaders(ctx: Ctx): Record<string, string> {
  const h: Record<string, string> = {
    "user-agent": UA_MOBILE,
    "x-ig-app-id": IG_APP,
    "x-requested-with": "XMLHttpRequest",
    referer: "https://www.instagram.com/",
    accept: "*/*",
  };
  if (ctx.cookie) {
    h.cookie = ctx.cookie;
    const c = /csrftoken=([^;]+)/.exec(ctx.cookie)?.[1];
    if (c) h["x-csrftoken"] = c;
  }
  return h;
}

function scToId(sc: string): string {
  const al = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  let n = BigInt(0);
  for (const c of sc.slice(0, 11)) n = n * BigInt(64) + BigInt(al.indexOf(c));
  return n.toString();
}

type IgMedia = {
  code?: string; pk?: string; media_type?: number; taken_at?: number;
  caption?: { text?: string } | null;
  video_versions?: { url: string; width: number; height: number }[];
  image_versions2?: { candidates: { url: string; width: number; height: number }[] };
  carousel_media?: IgMedia[];
  video_duration?: number;
  user?: { username?: string };
};

function igToItems(m: IgMedia, ctx: Ctx, base: string, out: MediaItem[]) {
  if (m.carousel_media?.length) {
    m.carousel_media.forEach((c, i) => igToItems(c, ctx, `${base}_${i + 1}`, out));
    return;
  }
  const img = m.image_versions2?.candidates?.[0];
  const thumb = img ? proxyUrl(img.url, { bypass: ctx.bypass }) : undefined;
  if (m.video_versions?.length) {
    const variants = m.video_versions.map((v) => mkVariant({ label: `${Math.min(v.width, v.height)}p`, url: v.url, title: base, ext: "mp4", height: Math.min(v.width, v.height), bypass: ctx.bypass }));
    out.push(mkItem({ title: base, kind: "video", thumb, duration: m.video_duration, variants }));
  } else if (img) {
    out.push(mkItem({ title: base, kind: "image", thumb, width: img.width, height: img.height, variants: [mkVariant({ label: "Orijinal", url: img.url, title: base, ext: "jpg", bypass: ctx.bypass })] }));
  }
}

async function igApi<T>(path: string, ctx: Ctx): Promise<T> {
  return getJson<T>(`https://www.instagram.com/api/v1/${path}`, { headers: igHeaders(ctx), bypass: ctx.bypass });
}

export async function instagramNative(ctx: Ctx): Promise<{ title: string; items: MediaItem[] } | null> {
  const p = ctx.url.pathname;
  const items: MediaItem[] = [];
  const post = /^\/(?:[^/]+\/)?(?:p|reel|reels|tv)\/([A-Za-z0-9_-]+)/.exec(p);
  const story = /^\/stories\/([^/]+)\/(\d+)/.exec(p);
  const hl = /^\/stories\/highlights\/(\d+)/.exec(p);
  const storiesUser = /^\/stories\/([^/]+)\/?$/.exec(p);
  const profile = /^\/([A-Za-z0-9._]+)\/?$/.exec(p);

  if (post || story) {
    const id = post ? scToId(post[1]) : story![2];
    if (ctx.cookie) {
      const j = await igApi<{ items?: IgMedia[] }>(`media/${id}/info/`, ctx);
      for (const m of j.items || []) igToItems(m, ctx, `instagram_${post ? post[1] : story![1] + "_" + id}`, items);
      return items.length ? { title: `Instagram ${post ? post[1] : "hikaye"}`, items } : null;
    }
    if (post) {
      // oturumsuz: embed sayfası
      const html = await getText(`https://www.instagram.com/p/${post[1]}/embed/captioned/`, { headers: { "user-agent": UA_DESKTOP }, bypass: ctx.bypass });
      const vid = /"video_url":"(.*?)"/.exec(html)?.[1];
      const base = `instagram_${post[1]}`;
      const thumbRaw = /class="EmbeddedMediaImage"[^>]*src="([^"]+)"/.exec(html)?.[1];
      const thumbU = thumbRaw ? thumbRaw.replace(/&amp;/g, "&") : undefined;
      if (vid) items.push(mkItem({ title: base, kind: "video", thumb: thumbU ? proxyUrl(thumbU, { bypass: ctx.bypass }) : undefined, variants: [mkVariant({ label: "Orijinal", url: unescapeJs(vid), title: base, ext: "mp4", bypass: ctx.bypass })] }));
      else if (thumbU) items.push(mkItem({ title: base, kind: "image", variants: [mkVariant({ label: "Orijinal", url: thumbU, title: base, ext: "jpg", bypass: ctx.bypass })] }));
      return items.length ? { title: base, items } : null;
    }
    return null;
  }

  if (!ctx.cookie) {
    ctx.warnings.push("Hikâye ve profil taramaları için Ayarlar → Oturum bölümünden Instagram girişi gerekir");
    return null;
  }
  if (hl) {
    const j = await igApi<{ reels?: Record<string, { items?: IgMedia[] }> }>(`feed/reels_media/?reel_ids=highlight:${hl[1]}`, ctx);
    for (const r of Object.values(j.reels || {})) (r.items || []).forEach((m, i) => igToItems(m, ctx, `instagram_highlight_${hl[1]}_${i + 1}`, items));
    return { title: "Instagram öne çıkan", items };
  }
  const uname = storiesUser?.[1] || (profile && !/^(explore|accounts|direct|reels?|p|tv)$/.test(profile[1]) ? profile[1] : undefined);
  if (uname) {
    const pi = await igApi<{ data?: { user?: { id: string } } }>(`users/web_profile_info/?username=${uname}`, ctx);
    const userId = pi.data?.user?.id;
    if (!userId) throw new Error("Kullanıcı bulunamadı");
    if (storiesUser) {
      const j = await igApi<{ reels?: Record<string, { items?: IgMedia[] }> }>(`feed/reels_media/?reel_ids=${userId}`, ctx);
      for (const r of Object.values(j.reels || {})) (r.items || []).forEach((m, i) => igToItems(m, ctx, `${uname}_story_${i + 1}`, items));
      return { title: `@${uname} hikâyeleri`, items };
    }
    let maxId = "";
    for (let page = 0; page < 5; page++) {
      const j = await igApi<{ items?: IgMedia[]; next_max_id?: string; more_available?: boolean }>(`feed/user/${userId}/?count=33${maxId ? `&max_id=${maxId}` : ""}`, ctx);
      for (const m of j.items || []) igToItems(m, ctx, `${uname}_${m.code || m.pk}`, items);
      if (!j.more_available || !j.next_max_id) break;
      maxId = j.next_max_id;
    }
    return { title: `@${uname}`, items };
  }
  return null;
}

/* =====================================================================
 *  Facebook (HTML yedek)
 * ===================================================================== */
export async function facebookFallback(ctx: Ctx): Promise<{ title: string; items: MediaItem[] } | null> {
  const headers: Record<string, string> = { "user-agent": UA_DESKTOP, "sec-fetch-mode": "navigate" };
  if (ctx.cookie) headers.cookie = ctx.cookie;
  const html = await getText(ctx.url.toString(), { headers, bypass: ctx.bypass });
  const grab = (keys: string[]) => {
    for (const k of keys) {
      const m = new RegExp(`"${k}":"(https:[^"]+)"`).exec(html);
      if (m) return unescapeJs(m[1]);
    }
  };
  const hd = grab(["browser_native_hd_url", "playable_url_quality_hd", "hd_src"]);
  const sd = grab(["browser_native_sd_url", "playable_url", "sd_src"]);
  const title = sanitize(/<meta property="og:title" content="([^"]*)"/.exec(html)?.[1] || "facebook video", 70) || "facebook video";
  const thumbRaw = /<meta property="og:image" content="([^"]+)"/.exec(html)?.[1];
  const variants = [];
  if (hd) variants.push(mkVariant({ label: "HD", url: hd, title, ext: "mp4", height: 720, bypass: ctx.bypass }));
  if (sd && sd !== hd) variants.push(mkVariant({ label: "SD", url: sd, title, ext: "mp4", height: 360, bypass: ctx.bypass }));
  if (!variants.length) return null;
  return {
    title,
    items: [mkItem({ title, kind: "video", thumb: thumbRaw ? proxyUrl(thumbRaw.replace(/&amp;/g, "&"), { bypass: ctx.bypass }) : undefined, variants })],
  };
}

/* =====================================================================
 *  YouTube (innertube yedek)
 * ===================================================================== */
export async function youtubeFallback(ctx: Ctx): Promise<{ title: string; items: MediaItem[] } | null> {
  const u = ctx.url;
  const id =
    u.searchParams.get("v") ||
    /^\/(?:shorts|embed|live|v)\/([\w-]{11})/.exec(u.pathname)?.[1] ||
    (u.hostname.includes("youtu.be") ? u.pathname.slice(1, 12) : undefined);
  if (!id) return null;
  const r = await fetchx("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "user-agent": "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
      "x-youtube-client-name": "28",
      "x-youtube-client-version": "1.60.19",
      ...(ctx.cookie ? { cookie: ctx.cookie } : {}),
    },
    body: JSON.stringify({
      context: { client: { clientName: "ANDROID_VR", clientVersion: "1.60.19", deviceMake: "Oculus", deviceModel: "Quest 3", androidSdkVersion: 32, osName: "Android", osVersion: "12L", hl: "tr" } },
      videoId: id,
      contentCheckOk: true,
      racyCheckOk: true,
    }),
    bypass: ctx.bypass,
  });
  const j = (await r.json()) as {
    playabilityStatus?: { status?: string; reason?: string };
    videoDetails?: { title?: string; lengthSeconds?: string; thumbnail?: { thumbnails: { url: string }[] } };
    streamingData?: { formats?: YtFmt[]; adaptiveFormats?: YtFmt[] };
  };
  if (j.playabilityStatus?.status && j.playabilityStatus.status !== "OK") {
    ctx.warnings.push(`YouTube: ${j.playabilityStatus.reason || j.playabilityStatus.status}`);
    return null;
  }
  const title = sanitize(j.videoDetails?.title || id, 90);
  const thumbs = j.videoDetails?.thumbnail?.thumbnails;
  const thumb = thumbs?.length ? proxyUrl(thumbs[thumbs.length - 1].url, { bypass: ctx.bypass }) : undefined;
  const fm = (j.streamingData?.formats || []).filter((f) => f.url);
  const ad = (j.streamingData?.adaptiveFormats || []).filter((f) => f.url);
  const items: MediaItem[] = [];
  const vars = fm
    .sort((a, b) => (b.height || 0) - (a.height || 0))
    .map((f) => mkVariant({ label: `${f.height}p`, url: f.url!, title, ext: "mp4", height: f.height, size: f.contentLength ? Number(f.contentLength) : undefined, bypass: ctx.bypass }));
  if (vars.length) items.push(mkItem({ title, kind: "video", thumb, duration: Number(j.videoDetails?.lengthSeconds) || undefined, variants: vars }));
  const au = ad.filter((f) => f.mimeType?.startsWith("audio/")).sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
  if (au.length) {
    const a = au.find((f) => f.mimeType?.includes("mp4")) || au[0];
    items.push(mkItem({ title: `${title} (ses)`, kind: "audio", thumb, variants: [mkVariant({ label: `${Math.round((a.bitrate || 0) / 1000)} kbps`, url: a.url!, title: `${title} ses`, ext: a.mimeType?.includes("webm") ? "webm" : "m4a", audioOnly: true, size: a.contentLength ? Number(a.contentLength) : undefined, bypass: ctx.bypass })] }));
  }
  return items.length ? { title, items } : null;
}
type YtFmt = { url?: string; height?: number; mimeType?: string; bitrate?: number; contentLength?: string };

/* =====================================================================
 *  Spotify (DRM'siz alan: 30 sn önizleme + kapak)
 * ===================================================================== */
export async function scanSpotify(ctx: Ctx): Promise<{ title: string; items: MediaItem[] }> {
  const m = /\/(track|album|playlist|episode|show|artist)\/([A-Za-z0-9]+)/.exec(ctx.url.pathname);
  if (!m) throw new Error("Spotify bağlantısı tanınmadı");
  const html = await getText(`https://open.spotify.com/embed/${m[1]}/${m[2]}`, { headers: { "user-agent": UA_DESKTOP }, bypass: ctx.bypass });
  const data = /<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/.exec(html)?.[1];
  if (!data) throw new Error("Spotify verisi okunamadı");
  const json = JSON.parse(data) as unknown;
  const tracks: { name: string; artist?: string; url?: string }[] = [];
  let cover: string | undefined;
  let main = "Spotify";
  const walk = (o: unknown, depth = 0) => {
    if (!o || typeof o !== "object" || depth > 30) return;
    if (Array.isArray(o)) return o.forEach((x) => walk(x, depth + 1));
    const r = o as Record<string, unknown>;
    const ap = r.audioPreview as { url?: string } | undefined;
    if (ap?.url && typeof r.title === "string") tracks.push({ name: r.title, artist: (r.subtitle as string) || undefined, url: ap.url });
    if (r.coverArt && !cover) {
      const s = (r.coverArt as { extractedColors?: unknown; sources?: { url: string; width?: number }[] }).sources;
      if (s?.length) cover = [...s].sort((a, b) => (b.width || 0) - (a.width || 0))[0].url;
    }
    if (typeof r.name === "string" && main === "Spotify" && r.type) main = r.name;
    for (const v of Object.values(r)) walk(v, depth + 1);
  };
  walk(json);
  const seen = new Set<string>();
  const items: MediaItem[] = [];
  const thumb = cover ? proxyUrl(cover, { bypass: ctx.bypass }) : undefined;
  for (const t of tracks) {
    if (!t.url || seen.has(t.url)) continue;
    seen.add(t.url);
    const title = sanitize(`${t.artist ? t.artist + " - " : ""}${t.name}`);
    items.push(mkItem({ title, kind: "audio", thumb, note: "Spotify DRM korumalıdır: yalnızca resmî 30 sn önizleme alınabilir", variants: [mkVariant({ label: "30 sn önizleme", url: t.url, title, ext: "mp3", audioOnly: true, bypass: ctx.bypass })] }));
  }
  if (cover) items.push(mkItem({ title: `${main} kapak`, kind: "image", thumb, variants: [mkVariant({ label: "Orijinal", url: cover, title: `${main} kapak`, ext: "jpg", bypass: ctx.bypass })] }));
  if (!tracks.length) ctx.warnings.push("Bu içerik için herkese açık ses önizlemesi bulunamadı");
  else ctx.warnings.push("Spotify tam parçaları DRM ile korur; yalnızca 30 saniyelik resmî önizlemeler indirilebilir");
  return { title: main, items };
}
