import type { Kind, MediaItem, ScanOptions, Variant } from "@/lib/types";
import { fetchx } from "./http";

export interface Ctx {
  url: URL;
  cookie?: string;
  bypass: boolean;
  warnings: string[];
  opts: ScanOptions;
}

const IMG = "jpg jpeg png gif webp avif bmp heic heif svg tif tiff jfif";
const VID = "mp4 m4v mov webm mkv avi flv ts m3u8 3gp wmv mpg mpeg ogv";
const AUD = "mp3 m4a aac wav flac ogg oga opus wma aiff";
const DOC = "pdf doc docx xls xlsx ppt pptx txt rtf csv epub odt ods odp md json xml mobi";
const ARC = "zip rar 7z tar gz tgz bz2 xz iso apk dmg";

const EXT_KIND: Record<string, Kind> = {};
for (const [list, kind] of [
  [IMG, "image"],
  [VID, "video"],
  [AUD, "audio"],
  [DOC, "document"],
  [ARC, "archive"],
] as const) {
  for (const e of list.split(" ")) EXT_KIND[e] = kind;
}

export const MEDIA_EXTS = Object.keys(EXT_KIND);

export function kindFromExt(ext?: string): Kind {
  return (ext && EXT_KIND[ext.toLowerCase()]) || "other";
}

export function kindFromMime(m?: string | null): Kind | undefined {
  if (!m) return undefined;
  const t = m.toLowerCase();
  if (t.startsWith("image/")) return "image";
  if (t.startsWith("video/") || t.includes("mpegurl")) return "video";
  if (t.startsWith("audio/")) return "audio";
  if (t.includes("pdf") || t.includes("msword") || t.includes("officedocument") || t.startsWith("text/plain"))
    return "document";
  if (t.includes("zip") || t.includes("rar") || t.includes("7z") || t.includes("tar") || t.includes("gzip"))
    return "archive";
  return undefined;
}

export const MIME_BY_EXT: Record<string, string> = {
  jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", gif: "image/gif", webp: "image/webp",
  avif: "image/avif", bmp: "image/bmp", svg: "image/svg+xml", mp4: "video/mp4", m4v: "video/mp4",
  mov: "video/quicktime", webm: "video/webm", mkv: "video/x-matroska", avi: "video/x-msvideo",
  mp3: "audio/mpeg", m4a: "audio/mp4", aac: "audio/aac", wav: "audio/wav", flac: "audio/flac",
  ogg: "audio/ogg", opus: "audio/ogg", pdf: "application/pdf", zip: "application/zip",
  txt: "text/plain",
};

export function extOf(u: string): string {
  try {
    const p = u.startsWith("http") ? new URL(u).pathname : u;
    const m = /\.([a-z0-9]{1,5})$/i.exec(decodeURIComponent(p));
    return m ? m[1].toLowerCase() : "";
  } catch {
    return "";
  }
}

export function sanitize(s: string, max = 90): string {
  return (
    s
      .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, max)
      .trim() || ""
  );
}

export function uid(): string {
  return Math.random().toString(36).slice(2, 10);
}

export function fileName(title: string, ext: string, suffix = ""): string {
  const base = sanitize(title) || "down-io";
  return `${base}${suffix}.${ext}`;
}

export function b64(o: unknown): string {
  return Buffer.from(JSON.stringify(o)).toString("base64url");
}

export function unb64<T>(s: string | null): T | undefined {
  if (!s) return undefined;
  try {
    return JSON.parse(Buffer.from(s, "base64url").toString("utf8")) as T;
  } catch {
    return undefined;
  }
}

export function proxyUrl(
  u: string,
  o: {
    headers?: Record<string, string>;
    name?: string;
    dl?: boolean;
    hls?: boolean;
    pl?: boolean;
    bypass?: boolean;
  } = {},
): string {
  const p = new URLSearchParams({ u });
  if (o.headers && Object.keys(o.headers).length) p.set("h", b64(o.headers));
  if (o.name) p.set("n", o.name);
  if (o.dl) p.set("d", "1");
  if (o.pl) p.set("pl", "1");
  if (o.bypass) p.set("b", "1");
  return `/api/${o.hls ? "hls" : "proxy"}?${p.toString()}`;
}

export interface VIn {
  label: string;
  url: string;
  title: string;
  headers?: Record<string, string>;
  ext?: string;
  size?: number;
  height?: number;
  hls?: boolean;
  bypass?: boolean;
  audioOnly?: boolean;
}

export function mkVariant(o: VIn): Variant {
  const ext = o.ext || (o.hls ? "ts" : extOf(o.url)) || "bin";
  const suffix = o.label && !/^(orijinal|original)$/i.test(o.label) ? ` [${o.label}]` : "";
  const filename = fileName(o.title, ext, suffix);
  return {
    id: uid(),
    label: o.label,
    height: o.height,
    size: o.size,
    ext,
    filename,
    audioOnly: o.audioOnly,
    previewUrl: proxyUrl(o.url, { headers: o.headers, bypass: o.bypass, pl: o.hls }),
    downloadUrl: o.hls
      ? proxyUrl(o.url, { headers: o.headers, bypass: o.bypass, name: filename, hls: true })
      : proxyUrl(o.url, { headers: o.headers, bypass: o.bypass, name: filename, dl: true }),
    src: o.url,
    hdr: o.headers,
  };
}

export function mkItem(o: {
  title: string;
  variants: Variant[];
  kind?: Kind;
  thumb?: string;
  duration?: number;
  width?: number;
  height?: number;
  folder?: string;
  note?: string;
  mime?: string;
  size?: number;
}): MediaItem {
  const v = o.variants[0];
  return {
    id: uid(),
    title: o.title,
    kind: o.kind || kindFromExt(v?.ext),
    ext: v?.ext || "bin",
    mime: o.mime,
    size: o.size ?? v?.size,
    thumb: o.thumb,
    duration: o.duration,
    width: o.width,
    height: o.height,
    folder: o.folder,
    note: o.note,
    variants: o.variants,
  };
}

export function cookieFor(host: string, cookies?: Record<string, string>): string | undefined {
  if (!cookies) return undefined;
  const h = host.toLowerCase();
  const key = /youtube\.com|youtu\.be|google\./.test(h)
    ? "youtube"
    : /instagram\.com/.test(h)
      ? "instagram"
      : /facebook\.com|fb\.watch|fb\.com/.test(h)
        ? "facebook"
        : /(^|\.)x\.com|twitter\.com/.test(h)
          ? "x"
          : /tiktok\.com/.test(h)
            ? "tiktok"
            : /spotify\./.test(h)
              ? "spotify"
              : /yandex\.|yadi\.sk/.test(h)
                ? "yandex"
                : "";
  const c = (key && cookies[key]) || cookies.other;
  return c && c.trim() ? c.trim().replace(/\r?\n/g, "; ") : undefined;
}

export function abs(href: string, base: string): string | null {
  try {
    if (!href || href.startsWith("data:") || href.startsWith("javascript:") || href.startsWith("blob:"))
      return null;
    return new URL(href.replace(/&amp;/g, "&"), base).toString();
  } catch {
    return null;
  }
}

export async function headInfo(
  url: string,
  headers: Record<string, string> | undefined,
  bypass: boolean,
): Promise<{ size?: number; mime?: string }> {
  try {
    let r = await fetchx(url, { method: "HEAD", headers, bypass, timeout: 7000 });
    if (!r.ok || !r.headers.get("content-length")) {
      r = await fetchx(url, { headers: { ...(headers || {}), range: "bytes=0-0" }, bypass, timeout: 7000 });
      r.body?.cancel().catch(() => {});
    }
    const cr = r.headers.get("content-range");
    const total = cr ? parseInt(cr.split("/")[1] || "", 10) : NaN;
    const cl = parseInt(r.headers.get("content-length") || "", 10);
    const size = isFinite(total) ? total : r.status === 206 ? undefined : isFinite(cl) ? cl : undefined;
    return { size, mime: r.headers.get("content-type")?.split(";")[0] || undefined };
  } catch {
    return {};
  }
}

export function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

export function unescapeJs(s: string): string {
  try {
    return JSON.parse(`"${s.replace(/"/g, '\\"').replace(/\\\\"/g, '\\"')}"`);
  } catch {
    return s.replace(/\\u0026/g, "&").replace(/\\u0025/g, "%").replace(/\\\//g, "/");
  }
}
