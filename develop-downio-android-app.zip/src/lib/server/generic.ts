import type { Kind, MediaItem } from "@/lib/types";
import { fetchx } from "./http";
import {
  type Ctx,
  MEDIA_EXTS,
  abs,
  decodeEntities,
  extOf,
  headInfo,
  kindFromExt,
  kindFromMime,
  mkItem,
  mkVariant,
  proxyUrl,
  sanitize,
} from "./util";
import { zipItems } from "./zip";

const EXT_RE = new RegExp(
  `https?:\\/\\/[^"'\\s<>\\\\)(]+?\\.(?:${MEDIA_EXTS.join("|")})(?:\\?[^"'\\s<>\\\\)(]*)?(?=["'\\s<>\\\\)(]|$)`,
  "gi",
);

function pickSrcset(s: string): string | undefined {
  let best: { u: string; w: number } | undefined;
  for (const part of s.split(",")) {
    const [u, d] = part.trim().split(/\s+/);
    if (!u) continue;
    const w = parseFloat(d || "1") || 1;
    if (!best || w > best.w) best = { u, w };
  }
  return best?.u;
}

const SKIP = /(sprite|pixel|spacer|1x1|favicon|blank\.|loading\.|\.ico(\?|$)|\.svg(\?|$)|gravatar|emoji|badge)/i;

export async function scanGeneric(ctx: Ctx): Promise<{ title: string; items: MediaItem[] }> {
  const url = ctx.url.toString();
  const hdr: Record<string, string> = { referer: ctx.url.origin + "/" };
  if (ctx.cookie) hdr.cookie = ctx.cookie;
  const r = await fetchx(url, { headers: { ...hdr, accept: "text/html,application/xhtml+xml,*/*" }, bypass: ctx.bypass });
  if (!r.ok && r.status !== 206) throw new Error(`Sayfa açılamadı (HTTP ${r.status})`);
  const ctype = (r.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
  const urlExt = extOf(url);

  // Doğrudan dosya
  if (ctype && !/html|xml|json|javascript/.test(ctype) && ctype !== "text/plain" || (MEDIA_EXTS.includes(urlExt) && !/html/.test(ctype))) {
    r.body?.cancel().catch(() => {});
    const size = parseInt(r.headers.get("content-length") || "", 10);
    const ext = urlExt || ctype.split("/")[1]?.replace(/[^a-z0-9].*$/, "") || "bin";
    const name = decodeURIComponent(ctx.url.pathname.split("/").pop() || "dosya") || "dosya";
    const title = name.replace(/\.[^.]+$/, "") || "dosya";
    const hls = ext === "m3u8" || /mpegurl/.test(ctype);
    const v = mkVariant({ label: "Orijinal", url, title, ext: hls ? undefined : ext, size: isFinite(size) ? size : undefined, hls, bypass: ctx.bypass, headers: hdr });
    const kind: Kind = kindFromExt(ext) !== "other" ? kindFromExt(ext) : kindFromMime(ctype) || "other";
    const items = [mkItem({ title, kind, variants: [v], mime: ctype })];
    if (ext === "zip") items.push(...(await zipItems(name, url, hdr, ctx.bypass, isFinite(size) ? size : undefined, ctx.warnings)));
    return { title, items };
  }

  const html = (await r.text()).slice(0, 6_000_000);
  const title = decodeEntities(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] || "").trim() || ctx.url.hostname;
  const found = new Map<string, { kind?: Kind; thumb?: string }>();
  const add = (raw: string | undefined | null, kind?: Kind) => {
    if (!raw) return;
    const u = abs(raw.replace(/\\\//g, "/").replace(/\\u0026/g, "&"), url);
    if (!u || SKIP.test(u) || !/^https?:/.test(u)) return;
    const k = u.split("#")[0];
    if (!found.has(k)) found.set(k, { kind });
  };
  const attr = (tag: string, name: string) =>
    new RegExp(`${name}\\s*=\\s*["']([^"']+)["']`, "i").exec(tag)?.[1];

  for (const m of html.matchAll(/<meta\b[^>]*>/gi)) {
    const t = m[0];
    const key = (attr(t, "property") || attr(t, "name") || attr(t, "itemprop") || "").toLowerCase();
    const content = attr(t, "content");
    if (/^(og:image(:secure_url|:url)?|twitter:image(:src)?|image)$/.test(key)) add(content, "image");
    else if (/^(og:video(:secure_url|:url)?|twitter:player:stream|contenturl)$/.test(key)) add(content, "video");
    else if (/^og:audio/.test(key)) add(content, "audio");
  }
  for (const m of html.matchAll(/<(video|audio|source|embed)\b[^>]*>/gi)) {
    const t = m[0];
    const k: Kind | undefined = m[1].toLowerCase() === "audio" ? "audio" : m[1].toLowerCase() === "video" ? "video" : /audio/.test(attr(t, "type") || "") ? "audio" : /video/.test(attr(t, "type") || "") ? "video" : undefined;
    add(attr(t, "src"), k);
    add(attr(t, "data-src"), k);
    add(attr(t, "poster"), "image");
  }
  for (const m of html.matchAll(/<img\b[^>]*>/gi)) {
    const t = m[0];
    const ss = attr(t, "srcset") || attr(t, "data-srcset");
    const best = ss ? pickSrcset(ss) : undefined;
    add(best || attr(t, "data-original") || attr(t, "data-full") || attr(t, "data-src") || attr(t, "src"), "image");
  }
  for (const m of html.matchAll(/<a\b[^>]*>/gi)) {
    const h = attr(m[0], "href");
    if (h && MEDIA_EXTS.includes(extOf(h.split("?")[0]))) add(h);
  }
  for (const m of html.matchAll(/<link\b[^>]*rel=["'](?:image_src|preload)["'][^>]*>/gi)) add(attr(m[0], "href"));
  const flat = html.replace(/\\\//g, "/").replace(/\\u0026/g, "&").replace(/&amp;/g, "&");
  for (const m of flat.matchAll(EXT_RE)) add(m[0]);

  // iframe içindeki bilinen oynatıcılar
  const embeds = [...html.matchAll(/<iframe\b[^>]*>/gi)]
    .map((m) => abs(attr(m[0], "src") || attr(m[0], "data-src") || "", url))
    .filter((u): u is string => !!u && /youtube|youtu\.be|vimeo|dailymotion|twitch|streamable|facebook|tiktok|instagram|rutube|ok\.ru|vk\.com|bilibili/.test(u))
    .slice(0, 3);

  const entries = [...found.entries()].slice(0, 120);
  const metas = await Promise.all(
    entries.map(async ([u], i) => {
      await new Promise((res) => setTimeout(res, Math.floor(i / 8) * 20));
      return headInfo(u, hdr, ctx.bypass);
    }),
  );
  const items: MediaItem[] = [];
  entries.forEach(([u, hint], i) => {
    const meta = metas[i];
    const ext = extOf(u.split("?")[0]) || extOf(u);
    let kind: Kind | undefined = kindFromMime(meta.mime);
    if (meta.mime && /html|json|javascript|css|xml/.test(meta.mime)) return;
    if (!kind || (kind === "other" && ext)) kind = ext ? kindFromExt(ext) : hint.kind;
    if (!kind || kind === "other") kind = hint.kind || "other";
    if (kind === "other" && !MEDIA_EXTS.includes(ext)) return;
    if (kind === "image" && meta.size !== undefined && meta.size < 4000) return;
    const hls = ext === "m3u8";
    const name = decodeURIComponent(new URL(u).pathname.split("/").pop() || "dosya");
    const t = sanitize(name.replace(/\.[^.]+$/, "")) || `${kind}-${i + 1}`;
    const finalExt = ext || (meta.mime?.split("/")[1] || "bin").replace(/[^a-z0-9].*$/, "");
    const v = mkVariant({ label: "Orijinal", url: u, title: t, ext: hls ? undefined : finalExt, size: meta.size, hls, bypass: ctx.bypass, headers: hdr });
    v.filename = ext ? name : v.filename;
    if (!hls) v.downloadUrl = proxyUrl(u, { headers: hdr, bypass: ctx.bypass, name: v.filename, dl: true });
    items.push(mkItem({ title: t, kind, mime: meta.mime, variants: [v] }));
  });

  (ctx as Ctx & { embeds?: string[] }).embeds = embeds;
  return { title, items };
}
