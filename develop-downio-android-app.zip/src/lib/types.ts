export type Kind = "image" | "video" | "audio" | "document" | "archive" | "other";

export interface Variant {
  id: string;
  label: string;
  height?: number;
  size?: number;
  ext: string;
  filename: string;
  audioOnly?: boolean;
  /** Tarayıcıda/oynatıcıda doğrudan açılabilen (indirmeden) akış adresi */
  previewUrl: string;
  /** Kaydedilecek dosya adresi (Content-Disposition: attachment) */
  downloadUrl: string;
  /** Sunucu içi kullanım; istemciye gönderilmeden silinir */
  src?: string;
  hdr?: Record<string, string>;
}

export interface MediaItem {
  id: string;
  title: string;
  kind: Kind;
  ext: string;
  mime?: string;
  size?: number;
  thumb?: string;
  duration?: number;
  width?: number;
  height?: number;
  folder?: string;
  note?: string;
  variants: Variant[];
}

export interface ScanResult {
  url: string;
  platform: string;
  title: string;
  items: MediaItem[];
  warnings: string[];
  locked?: "password";
}

export interface ScanOptions {
  bypass?: boolean;
  password?: string;
  cookies?: Record<string, string>;
}

export const KIND_LABEL: Record<Kind, string> = {
  image: "Fotoğraf",
  video: "Video",
  audio: "Ses",
  document: "Belge",
  archive: "Arşiv",
  other: "Diğer",
};

export function formatBytes(n?: number | null): string {
  if (n === undefined || n === null || !isFinite(n) || n < 0) return "Boyut ?";
  if (n < 1024) return `${n} B`;
  const u = ["KB", "MB", "GB", "TB"];
  let v = n / 1024;
  let i = 0;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v >= 100 ? v.toFixed(0) : v.toFixed(1)} ${u[i]}`;
}

export function formatDuration(s?: number): string {
  if (!s || !isFinite(s)) return "";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
    : `${m}:${String(sec).padStart(2, "0")}`;
}

export function pickVariant(item: MediaItem, quality: string): Variant {
  const vs = item.variants;
  if (vs.length <= 1 || item.kind !== "video") return vs[0];
  const sorted = [...vs].sort((a, b) => (b.height ?? 0) - (a.height ?? 0));
  if (quality === "worst") return sorted[sorted.length - 1];
  const n = parseInt(quality, 10);
  if (!n) return sorted[0];
  return (
    sorted.find((v) => (v.height ?? 0) > 0 && (v.height ?? 0) <= n) ??
    sorted[sorted.length - 1]
  );
}
