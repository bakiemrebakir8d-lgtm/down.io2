"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { native } from "./native";

export interface Settings {
  theme: "auto" | "light" | "dark";
  haptic: boolean;
  tutorialSeen: boolean;
  folder: string;
  byType: boolean;
  quality: "best" | "1080" | "720" | "480" | "worst";
  autoClipboard: boolean;
  concurrent: number;
  bypass: boolean;
  cookies: Record<string, string>;
}

export const DEFAULTS: Settings = {
  theme: "auto",
  haptic: true,
  tutorialSeen: false,
  folder: "Down.io",
  byType: true,
  quality: "best",
  autoClipboard: true,
  concurrent: 3,
  bypass: false,
  cookies: {},
};

interface Ctx {
  s: Settings;
  ready: boolean;
  set: (p: Partial<Settings>) => void;
  setCookie: (key: string, value: string) => void;
  tap: (k?: "light" | "success" | "error") => void;
}

const SettingsCtx = createContext<Ctx | null>(null);
const KEY = "downio.settings.v1";

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<Settings>(DEFAULTS);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setS({ ...DEFAULTS, ...JSON.parse(raw) });
    } catch {
      /* yoksay */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(KEY, JSON.stringify(s));
  }, [s, ready]);

  useEffect(() => {
    const el = document.documentElement;
    if (s.theme === "auto") el.removeAttribute("data-theme");
    else el.setAttribute("data-theme", s.theme);
  }, [s.theme]);

  const set = useCallback((p: Partial<Settings>) => setS((prev) => ({ ...prev, ...p })), []);
  const setCookie = useCallback(
    (key: string, value: string) =>
      setS((prev) => {
        const cookies = { ...prev.cookies };
        if (value.trim()) cookies[key] = value.trim();
        else delete cookies[key];
        return { ...prev, cookies };
      }),
    [],
  );
  const tap = useCallback(
    (k: "light" | "success" | "error" = "light") => {
      if (s.haptic) native.haptic(k);
    },
    [s.haptic],
  );

  useEffect(() => {
    window.__onLoginCookies = (key, cookies) => setCookie(key, cookies);
    return () => {
      window.__onLoginCookies = undefined;
    };
  }, [setCookie]);

  const value = useMemo(() => ({ s, ready, set, setCookie, tap }), [s, ready, set, setCookie, tap]);
  return <SettingsCtx.Provider value={value}>{children}</SettingsCtx.Provider>;
}

export function useSettings(): Ctx {
  const c = useContext(SettingsCtx);
  if (!c) throw new Error("SettingsProvider eksik");
  return c;
}
