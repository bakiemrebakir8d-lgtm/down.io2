"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Kind } from "@/lib/types";
import { native } from "./native";
import { useSettings } from "./settings";

export interface JobIn {
  title: string;
  filename: string;
  kind: Kind;
  size?: number;
  url: string;
  sourceUrl: string;
  mediaUrl: string;
  quality?: string;
}

export interface Job extends JobIn {
  id: string;
  status: "queued" | "running" | "done" | "error" | "canceled";
  loaded: number;
  total: number;
  localId?: string;
  error?: string;
}

interface Ctx {
  jobs: Job[];
  enqueue: (list: JobIn[]) => void;
  cancel: (id: string) => void;
  clearFinished: () => void;
  active: number;
}

const DlCtx = createContext<Ctx | null>(null);
const KIND_DIR: Record<Kind, string> = {
  image: "Fotoğraflar",
  video: "Videolar",
  audio: "Ses",
  document: "Belgeler",
  archive: "Arşivler",
  other: "Diğer",
};

const clean = (s: string) => s.replace(/[\\:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim();

export function DownloadsProvider({ children }: { children: ReactNode }) {
  const { s, tap } = useSettings();
  const [jobs, setJobs] = useState<Job[]>([]);
  const jobsRef = useRef<Job[]>([]);
  jobsRef.current = jobs;
  const started = useRef<Set<string>>(new Set());

  const patch = useCallback((id: string, p: Partial<Job>) => {
    setJobs((prev) => prev.map((j) => (j.id === id ? { ...j, ...p } : j)));
  }, []);

  const record = useCallback((j: Job) => {
    fetch("/api/history", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        title: j.title,
        filename: j.filename,
        kind: j.kind,
        size: j.total > 0 ? j.total : j.size,
        sourceUrl: j.sourceUrl,
        mediaUrl: j.mediaUrl,
        localId: j.localId,
        quality: j.quality,
      }),
    }).catch(() => {});
  }, []);

  const enqueue = useCallback((list: JobIn[]) => {
    setJobs((prev) => [
      ...prev,
      ...list.map<Job>((j) => ({
        ...j,
        id: Math.random().toString(36).slice(2),
        status: "queued",
        loaded: 0,
        total: j.size || 0,
      })),
    ]);
  }, []);

  const startJob = useCallback(
    (j: Job) => {
      const abs = new URL(j.url, window.location.origin).toString();
      if (native.available()) {
        const dir = [clean(s.folder) || "Down.io", s.byType ? KIND_DIR[j.kind] : ""].filter(Boolean).join("/");
        const localId = native.startDownload(abs, clean(j.filename), dir);
        if (!localId) return patch(j.id, { status: "error", error: "Başlatılamadı" });
        patch(j.id, { localId });
      } else {
        const a = document.createElement("a");
        a.href = abs;
        a.download = j.filename;
        a.rel = "noopener";
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.setTimeout(() => {
          patch(j.id, { status: "done", loaded: j.size || 0, total: j.size || 0 });
          record(j);
          tap("success");
        }, 900);
      }
    },
    [s.folder, s.byType, patch, record, tap],
  );

  // Eşzamanlı indirme limiti
  useEffect(() => {
    const running = jobs.filter((j) => j.status === "running").length;
    const slots = Math.max(1, s.concurrent) - running;
    if (slots <= 0) return;
    const next = jobs.filter((j) => j.status === "queued" && !started.current.has(j.id)).slice(0, slots);
    if (!next.length) return;
    next.forEach((j) => started.current.add(j.id));
    setJobs((prev) => prev.map((j) => (next.some((n) => n.id === j.id) ? { ...j, status: "running" } : j)));
    next.forEach(startJob);
  }, [jobs, s.concurrent, startJob]);

  // Android DownloadManager ilerleme yoklaması
  useEffect(() => {
    if (!native.available()) return;
    const t = window.setInterval(() => {
      for (const j of jobsRef.current) {
        if (j.status !== "running" || !j.localId) continue;
        const q = native.query(j.localId);
        if (!q) continue;
        if (q.status === "done") {
          const done = { ...j, status: "done" as const, loaded: q.total > 0 ? q.total : q.loaded, total: q.total > 0 ? q.total : q.loaded };
          patch(j.id, { status: "done", loaded: done.loaded, total: done.total });
          record(done);
          tap("success");
        } else if (q.status === "failed" || q.status === "missing") {
          patch(j.id, { status: "error", error: "İndirme başarısız" });
          tap("error");
        } else {
          patch(j.id, { loaded: q.loaded, total: q.total > 0 ? q.total : j.total });
        }
      }
    }, 800);
    return () => window.clearInterval(t);
  }, [patch, record, tap]);

  const cancel = useCallback(
    (id: string) => {
      const j = jobsRef.current.find((x) => x.id === id);
      if (j?.localId) native.cancel(j.localId);
      patch(id, { status: "canceled" });
    },
    [patch],
  );
  const clearFinished = useCallback(
    () => setJobs((prev) => prev.filter((j) => j.status === "queued" || j.status === "running")),
    [],
  );

  const active = jobs.filter((j) => j.status === "queued" || j.status === "running").length;
  const value = useMemo(() => ({ jobs, enqueue, cancel, clearFinished, active }), [jobs, enqueue, cancel, clearFinished, active]);
  return <DlCtx.Provider value={value}>{children}</DlCtx.Provider>;
}

export function useDownloads(): Ctx {
  const c = useContext(DlCtx);
  if (!c) throw new Error("DownloadsProvider eksik");
  return c;
}
