/* Android WebView köprüsü (window.Android). Tarayıcıda her şey sessizce yedeğe düşer. */
type Bridge = {
  startDownload(url: string, filename: string, folder: string, mime: string): string;
  queryDownload(id: string): string;
  cancelDownload(id: string): void;
  openDownload(id: string): boolean;
  haptic(kind: string): void;
  getClipboard(): string;
  openLogin(loginUrl: string, cookieUrl: string, key: string): void;
  clearCache(): void;
  getServerUrl(): string;
  setServerUrl(url: string): void;
  getVersion(): string;
};

declare global {
  interface Window {
    Android?: Bridge;
    __onLoginCookies?: (key: string, cookies: string) => void;
  }
}

const b = (): Bridge | undefined => (typeof window !== "undefined" ? window.Android : undefined);

export interface NativeProgress {
  status: "pending" | "running" | "paused" | "done" | "failed" | "missing";
  loaded: number;
  total: number;
}

export const native = {
  available: () => !!b(),
  version: () => b()?.getVersion?.() || "1.0.0",
  startDownload(url: string, filename: string, folder: string, mime = "*/*"): string {
    return b()?.startDownload(url, filename, folder, mime) || "";
  },
  query(id: string): NativeProgress | null {
    try {
      const r = b()?.queryDownload(id);
      return r ? (JSON.parse(r) as NativeProgress) : null;
    } catch {
      return null;
    }
  },
  cancel: (id: string) => b()?.cancelDownload(id),
  open: (id: string) => !!b()?.openDownload(id),
  haptic: (kind: "light" | "success" | "error") => {
    try {
      if (b()) b()!.haptic(kind);
      else if (typeof navigator !== "undefined" && navigator.vibrate) navigator.vibrate(kind === "light" ? 8 : kind === "success" ? [10, 40, 10] : [30, 40, 30]);
    } catch {
      /* yoksay */
    }
  },
  async clipboard(): Promise<string> {
    try {
      if (b()) return b()!.getClipboard() || "";
      return (await navigator.clipboard.readText()) || "";
    } catch {
      return "";
    }
  },
  openLogin: (loginUrl: string, cookieUrl: string, key: string) => b()?.openLogin(loginUrl, cookieUrl, key),
  clearCache: () => b()?.clearCache(),
  getServerUrl: () => b()?.getServerUrl() || "",
  setServerUrl: (u: string) => b()?.setServerUrl(u),
};

export function isUrl(s: string): boolean {
  return /^(https?:\/\/)?([a-z0-9-]+\.)+[a-z]{2,}(:\d+)?(\/\S*)?$/i.test(s.trim());
}

export const PLATFORMS = [
  { key: "youtube", name: "YouTube", login: "https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F", cookieUrl: "https://www.youtube.com" },
  { key: "instagram", name: "Instagram", login: "https://www.instagram.com/accounts/login/", cookieUrl: "https://www.instagram.com" },
  { key: "facebook", name: "Facebook", login: "https://www.facebook.com/login", cookieUrl: "https://www.facebook.com" },
  { key: "x", name: "X (Twitter)", login: "https://x.com/i/flow/login", cookieUrl: "https://x.com" },
  { key: "tiktok", name: "TikTok", login: "https://www.tiktok.com/login", cookieUrl: "https://www.tiktok.com" },
  { key: "spotify", name: "Spotify", login: "https://accounts.spotify.com/login", cookieUrl: "https://open.spotify.com" },
  { key: "yandex", name: "Yandex Disk", login: "https://passport.yandex.com/auth", cookieUrl: "https://disk.yandex.com" },
  { key: "other", name: "Diğer siteler", login: "", cookieUrl: "" },
] as const;

export async function copyText(t: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(t);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = t;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}
