package io.down.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Gizli/özel hesap gerektiren platformlar için uygulama içi giriş ekranı.
 * Kullanıcı giriş yapıp "Bitti"ye dokunduğunda oturum çerezleri (SessionID dahil)
 * Down.io'ya aktarılır ve taramalarda otomatik kullanılır.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var cookieUrl = ""
    private var key = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val loginUrl = intent.getStringExtra("loginUrl") ?: run { finish(); return }
        cookieUrl = intent.getStringExtra("cookieUrl") ?: loginUrl
        key = intent.getStringExtra("key") ?: ""

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(6), dp(8), dp(6))
        }
        val title = TextView(this).apply {
            text = "Giriş yapın, ardından Bitti'ye dokunun"
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val cancel = Button(this).apply {
            text = "İptal"
            minHeight = dp(48)
            minimumHeight = dp(48)
            setOnClickListener { finish() }
        }
        val done = Button(this).apply {
            text = "Bitti"
            minHeight = dp(48)
            minimumHeight = dp(48)
            setOnClickListener { finishWithCookies() }
        }
        bar.addView(title)
        bar.addView(cancel)
        bar.addView(done)
        root.addView(bar)

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            // Google gibi servisler "; wv" içeren gömülü tarayıcıları engeller
            userAgentString = userAgentString.replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
        }
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)
        web.webViewClient = WebViewClient()
        web.setBackgroundColor(Color.WHITE)
        web.loadUrl(loginUrl)
    }

    private fun finishWithCookies() {
        val cm = CookieManager.getInstance()
        cm.flush()
        val merged = LinkedHashMap<String, String>()
        listOfNotNull(cm.getCookie(cookieUrl), web.url?.let { cm.getCookie(it) }).forEach { raw ->
            raw.split(";").map { it.trim() }.filter { it.contains("=") }.forEach { kv ->
                merged[kv.substringBefore("=")] = kv.substringAfter("=")
            }
        }
        val cookies = merged.entries.joinToString("; ") { "${it.key}=${it.value}" }
        setResult(RESULT_OK, Intent().putExtra("key", key).putExtra("cookies", cookies))
        finish()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
