package io.down.app

import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.view.HapticFeedbackConstants
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.io.File

/** Web arayüzünün (window.Android) yerel Android özelliklerine eriştiği köprü. */
class Bridge(private val act: MainActivity, private val web: WebView) {

    private val dm: DownloadManager
        get() = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    private fun safe(s: String): String =
        s.replace(Regex("[\\\\:*?\"<>|]+"), " ").replace(Regex("\\s+"), " ").trim()

    @JavascriptInterface
    fun startDownload(url: String, filename: String, folder: String, mime: String): String {
        return try {
            val dir = folder.split("/").map { safe(it) }.filter { it.isNotEmpty() }.joinToString("/")
            val name = safe(filename).ifEmpty { "down-io-dosya" }
            val sub = if (dir.isEmpty()) name else "$dir/$name"
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setDescription("Down.io")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, sub)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
            if (mime.isNotBlank() && mime != "*/*") req.setMimeType(mime)
            dm.enqueue(req).toString()
        } catch (e: Exception) {
            ""
        }
    }

    @JavascriptInterface
    fun queryDownload(id: String): String {
        val json = JSONObject()
        try {
            dm.query(DownloadManager.Query().setFilterById(id.toLong())).use { c ->
                if (!c.moveToFirst()) {
                    return json.put("status", "missing").put("loaded", 0).put("total", 0).toString()
                }
                val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val loaded = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val name = when (st) {
                    DownloadManager.STATUS_PENDING -> "pending"
                    DownloadManager.STATUS_RUNNING -> "running"
                    DownloadManager.STATUS_PAUSED -> "paused"
                    DownloadManager.STATUS_SUCCESSFUL -> "done"
                    else -> "failed"
                }
                json.put("status", name).put("loaded", loaded).put("total", total)
            }
        } catch (e: Exception) {
            json.put("status", "missing").put("loaded", 0).put("total", 0)
        }
        return json.toString()
    }

    @JavascriptInterface
    fun cancelDownload(id: String) {
        try {
            dm.remove(id.toLong())
        } catch (_: Exception) {
        }
    }

    @JavascriptInterface
    fun openDownload(id: String): Boolean {
        return try {
            val did = id.toLong()
            var exists = false
            dm.query(DownloadManager.Query().setFilterById(did)).use { c ->
                if (c.moveToFirst()) {
                    val local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                    exists = local != null && File(Uri.parse(local).path ?: "").exists()
                }
            }
            if (!exists) return false
            val uri = dm.getUriForDownloadedFile(did) ?: return false
            val mime = dm.getMimeTypeForDownloadedFile(did) ?: "*/*"
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun haptic(kind: String) {
        web.post {
            val c = when (kind) {
                "success" -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
                "error" -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.LONG_PRESS
                else -> HapticFeedbackConstants.VIRTUAL_KEY
            }
            web.performHapticFeedback(c)
        }
    }

    @JavascriptInterface
    fun getClipboard(): String {
        return try {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(act)?.toString() ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    @JavascriptInterface
    fun openLogin(loginUrl: String, cookieUrl: String, key: String) {
        act.runOnUiThread { act.launchLogin(loginUrl, cookieUrl.ifEmpty { loginUrl }, key) }
    }

    @JavascriptInterface
    fun clearCache() {
        web.post {
            web.clearCache(true)
            web.clearFormData()
        }
    }

    @JavascriptInterface
    fun getServerUrl(): String = act.serverUrl()

    @JavascriptInterface
    fun setServerUrl(url: String) {
        act.saveServerUrl(url)
        act.runOnUiThread { act.loadStart(null) }
    }

    @JavascriptInterface
    fun reload() {
        act.runOnUiThread { act.loadStart(null) }
    }

    @JavascriptInterface
    fun getVersion(): String = try {
        act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "1.0.0"
    } catch (e: Exception) {
        "1.0.0"
    }
}
